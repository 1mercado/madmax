package com.example

import com.example.data.DigiCashRepository
import com.example.model.CompensationMechanics
import com.example.model.UserTier
import org.junit.Assert.*
import org.junit.Test

class DigiCashCompensationTest {

    @Test
    fun testBasicSubscription60_40Split() {
        val split = CompensationMechanics.calculateSplit(500.0)

        // 60% of 500 = 300, split across VIP 1, 2, 3 -> 100 each
        assertEquals(300.0, split.vipPoolTotal, 0.001)
        assertEquals(100.0, split.vip1Share, 0.001)
        assertEquals(100.0, split.vip2Share, 0.001)
        assertEquals(100.0, split.vip3Share, 0.001)

        // 40% of 500 = 200 retained in subscriber's wallet
        assertEquals(200.0, split.subscriberCashback, 0.001)
    }

    @Test
    fun testBuilderUpgrade60_40Split() {
        val split = CompensationMechanics.calculateSplit(5000.0)

        // 60% of 5000 = 3000, split across VIP 1, 2, 3 -> 1000 each
        assertEquals(3000.0, split.vipPoolTotal, 0.001)
        assertEquals(1000.0, split.vip1Share, 0.001)
        assertEquals(1000.0, split.vip2Share, 0.001)
        assertEquals(1000.0, split.vip3Share, 0.001)

        // 40% of 5000 = 2000 retained in subscriber's wallet
        assertEquals(2000.0, split.subscriberCashback, 0.001)
    }

    @Test
    fun testUnilevelPercentagesLevel1To10() {
        // Level 1 to 3
        assertEquals(50.0, CompensationMechanics.calculateCommission(500.0, 1), 0.001) // 10%
        assertEquals(25.0, CompensationMechanics.calculateCommission(500.0, 2), 0.001) // 5%
        assertEquals(20.0, CompensationMechanics.calculateCommission(500.0, 3), 0.001) // 4%

        // Levels 4 to 10 on Builder Upgrade (₱5,000)
        assertEquals(150.0, CompensationMechanics.calculateCommission(5000.0, 4), 0.001) // 3%
        assertEquals(100.0, CompensationMechanics.calculateCommission(5000.0, 5), 0.001) // 2%
        assertEquals(75.0, CompensationMechanics.calculateCommission(5000.0, 6), 0.001)  // 1.5%
        assertEquals(50.0, CompensationMechanics.calculateCommission(5000.0, 7), 0.001)  // 1%
        assertEquals(37.5, CompensationMechanics.calculateCommission(5000.0, 8), 0.001)  // 0.75%
        assertEquals(25.0, CompensationMechanics.calculateCommission(5000.0, 9), 0.001)  // 0.5%
        assertEquals(12.5, CompensationMechanics.calculateCommission(5000.0, 10), 0.001) // 0.25%
    }

    @Test
    fun testTierLevelUnlocking() {
        // Basic tier unlocks only levels 1 to 3
        assertTrue(CompensationMechanics.isLevelUnlocked(1, UserTier.BASIC))
        assertTrue(CompensationMechanics.isLevelUnlocked(2, UserTier.BASIC))
        assertTrue(CompensationMechanics.isLevelUnlocked(3, UserTier.BASIC))
        assertFalse(CompensationMechanics.isLevelUnlocked(4, UserTier.BASIC))
        assertFalse(CompensationMechanics.isLevelUnlocked(10, UserTier.BASIC))

        // Builder unlocks up to level 10
        assertTrue(CompensationMechanics.isLevelUnlocked(4, UserTier.BUILDER))
        assertTrue(CompensationMechanics.isLevelUnlocked(7, UserTier.BUILDER))
        assertTrue(CompensationMechanics.isLevelUnlocked(10, UserTier.BUILDER))
    }

    @Test
    fun testRepositoryBuilderUpgradeExecution() {
        val repo = DigiCashRepository()
        val initialBalance = repo.userProfile.value.balance // 12,450.00

        val result = repo.upgradeToBuilder()
        assertTrue(result.isSuccess)

        // ₱5,000 cost, but 40% (₱2,000) is instant cashback rebate -> Net deduction is ₱3,000
        val expectedBalance = initialBalance - 3000.0
        assertEquals(expectedBalance, repo.userProfile.value.balance, 0.001)
        assertEquals(UserTier.BUILDER, repo.userProfile.value.tier)
    }

    @Test
    fun testSavingsGoalProgressCalculation() {
        val goal = com.example.model.SavingsGoal(
            id = "SG-TEST",
            title = "Test Car Fund",
            category = "Vehicle",
            targetAmount = 10000.0,
            currentAmount = 7500.0
        )

        assertEquals(0.75f, goal.progress, 0.001f)
        assertEquals(75, goal.progressPercent)
        assertEquals(2500.0, goal.remainingAmount, 0.001)
        assertFalse(goal.isGoalReached)

        val completedGoal = goal.copy(currentAmount = 10000.0)
        assertTrue(completedGoal.isGoalReached)
        assertEquals(100, completedGoal.progressPercent)
        assertEquals(0.0, completedGoal.remainingAmount, 0.001)
    }

    @Test
    fun testSavingsVaultDepositAndWithdrawFlow() {
        val repo = DigiCashRepository()
        val initialWalletBalance = repo.userProfile.value.balance // 12,450.00

        // Create new goal with ₱1,000 initial deposit
        val createResult = repo.createSavingsGoal(
            title = "New Laptop",
            category = "Gadget",
            targetAmount = 50000.0,
            initialDeposit = 1000.0
        )
        assertTrue(createResult.isSuccess)
        val goal = createResult.getOrThrow()

        // Wallet balance should decrease by initial deposit
        assertEquals(initialWalletBalance - 1000.0, repo.userProfile.value.balance, 0.001)
        assertEquals(1000.0, goal.currentAmount, 0.001)

        // Deposit additional ₱2,000 to the goal
        val depositResult = repo.depositToGoal(goal.id, 2000.0)
        assertTrue(depositResult.isSuccess)
        assertEquals(initialWalletBalance - 3000.0, repo.userProfile.value.balance, 0.001)

        val updatedGoal = repo.savingsGoals.value.first { it.id == goal.id }
        assertEquals(3000.0, updatedGoal.currentAmount, 0.001)

        // Withdraw ₱1,500 back to wallet
        val withdrawResult = repo.withdrawFromGoal(goal.id, 1500.0)
        assertTrue(withdrawResult.isSuccess)
        assertEquals(initialWalletBalance - 1500.0, repo.userProfile.value.balance, 0.001)

        val finalGoal = repo.savingsGoals.value.first { it.id == goal.id }
        assertEquals(1500.0, finalGoal.currentAmount, 0.001)
    }
}
