package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalThemeIsDark = compositionLocalOf { true }
val LocalThemeToggle = compositionLocalOf<() -> Unit> { {} }

private val DigiCashDarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = Color(0xFF00222B),
    primaryContainer = Color(0xFF004D5C),
    onPrimaryContainer = Color(0xFF8CF4FF),
    secondary = EmeraldMint,
    onSecondary = Color(0xFF003822),
    secondaryContainer = Color(0xFF005234),
    onSecondaryContainer = Color(0xFF86F8BF),
    tertiary = PurpleNeon,
    onTertiary = Color(0xFF280068),
    tertiaryContainer = Color(0xFF45009E),
    onTertiaryContainer = Color(0xFFEADBFF),
    background = BgDeepDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = CardBorder,
    error = ErrorRed,
    onError = Color.White
)

private val DigiCashLightColorScheme = lightColorScheme(
    primary = Color(0xFF00838F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F7FA),
    onPrimaryContainer = Color(0xFF00363A),
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2F1),
    onSecondaryContainer = Color(0xFF004D40),
    tertiary = Color(0xFF651FFF),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFEDE7F6),
    onTertiaryContainer = Color(0xFF311B92),
    background = Color(0xFFF4F8FD),
    onBackground = Color(0xFF0B192C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B192C),
    surfaceVariant = Color(0xFFE5EEF8),
    onSurfaceVariant = Color(0xFF455A64),
    outline = Color(0xFF80DEEA),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun DigiCashTheme(
    darkTheme: Boolean = true,
    onToggleTheme: () -> Unit = {},
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DigiCashDarkColorScheme else DigiCashLightColorScheme
    CompositionLocalProvider(
        LocalThemeIsDark provides darkTheme,
        LocalThemeToggle provides onToggleTheme
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

