package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DigiCash Cyber-Fintech Color Palette
val BgDeepDark = Color(0xFF040914)
val BgMidnight = Color(0xFF07172E)
val BgDeepNavy = Color(0xFF091C36)
val BgCardGlass = Color(0xCC0D2240)
val BgCardGlassLight = Color(0x99132F57)
val CardBorder = Color(0x3300E5FF)

// Vibrant Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanBright = Color(0xFF00F2FE)
val EmeraldMint = Color(0xFF00D294)
val EmeraldGreen = Color(0xFF00E676)
val ElectricBlue = Color(0xFF1E88E5)
val PurpleNeon = Color(0xFF7C4DFF)
val PurpleDeep = Color(0xFF651FFF)
val GoldYellow = Color(0xFFFFB300)
val GoldBright = Color(0xFFFFD54F)

// UI Surfaces
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF90A4AE)
val TextMuted = Color(0xFF607D8B)
val ErrorRed = Color(0xFFFF5252)
val SuccessGreen = Color(0xFF00E676)

// Surface colors for M3
val SurfaceDark = Color(0xFF091A33)
val SurfaceCard = Color(0xFF0E2445)
val SurfaceBorder = Color(0x2E00E5FF)
