package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun ServicesHubScreen(
    onSendClick: () -> Unit,
    onReceiveClick: () -> Unit,
    onScanQrClick: () -> Unit = onReceiveClick,
    onPayBillsClick: () -> Unit,
    onTopUpClick: () -> Unit,
    onSavingsVaultClick: () -> Unit = {},
    onRewardsClick: () -> Unit,
    onReferralsClick: () -> Unit,
    onBuilderClick: () -> Unit,
    onVipClick: () -> Unit
) {
    DigiCashBackdrop {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(bottom = 90.dp, top = 16.dp, start = 20.dp, end = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Text(
                    text = "All Services",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Explore the complete DigiCash ecosystem",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            // Financial & Wallet
            item {
                Text(
                    text = "Financial & Transfers",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon
                )
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 18.dp,
                    backgroundColor = Color(0xCC091E3B)
                ) {
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        HubRow(
                            icon = Icons.AutoMirrored.Filled.Send,
                            title = "Send Money",
                            subtitle = "To Mobile, Bank, GCash & Maya",
                            color = CyanNeon,
                            onClick = onSendClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.QrCodeScanner,
                            title = "Scan QR Ph to Pay",
                            subtitle = "Instant camera scan for merchants & users",
                            color = EmeraldMint,
                            onClick = onScanQrClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.QrCode,
                            title = "My QR Code & Account",
                            subtitle = "Receive funds from any bank or e-wallet",
                            color = Color(0xFF80D8FF),
                            onClick = onReceiveClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.ReceiptLong,
                            title = "Pay Bills",
                            subtitle = "Utilities, Government, Telecom, Loans",
                            color = PurpleNeon,
                            onClick = onPayBillsClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.PhoneAndroid,
                            title = "Buy Load & Gaming Pins",
                            subtitle = "Smart, Globe, DITO, TNT, MLBB, Steam",
                            color = Color(0xFF40C4FF),
                            onClick = onTopUpClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.Savings,
                            title = "Savings Vault (6.0% P.A.)",
                            subtitle = "Goal-based savings with visual progress tracking",
                            color = EmeraldMint,
                            onClick = onSavingsVaultClick
                        )
                    }
                }
            }

            // Unilevel, Rewards & Tiers
            item {
                Text(
                    text = "Referral Network & VIP Tiers",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldYellow
                )
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 18.dp,
                    backgroundColor = Color(0xCC091E3B)
                ) {
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        HubRow(
                            icon = Icons.Default.RocketLaunch,
                            title = "Builder Pack Upgrade (₱5,000)",
                            subtitle = "Unlocks Levels 4-10 • Instant 40% rebate",
                            color = EmeraldMint,
                            onClick = onBuilderClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.Group,
                            title = "Referral Program & 10-Level Tree",
                            subtitle = "10% direct + unilevel commissions",
                            color = CyanNeon,
                            onClick = onReferralsClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.WorkspacePremium,
                            title = "VIP Membership Club",
                            subtitle = "VIP 1, 2, 3 Infinity Pool share",
                            color = GoldYellow,
                            onClick = onVipClick
                        )
                        HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))
                        HubRow(
                            icon = Icons.Default.CardGiftcard,
                            title = "Rewards Center",
                            subtitle = "Redeem points for cash vouchers & load",
                            color = Color(0xFFFF80AB),
                            onClick = onRewardsClick
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HubRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(16.dp)
        )
    }
}
