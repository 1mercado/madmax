package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun TopUpScreen(
    currentBalance: Double,
    onBack: () -> Unit,
    onBuyLoad: (String, String, Double) -> Unit,
    onCashIn: (Double, String) -> Unit
) {
    val context = LocalContext.current
    val tabs = listOf("Mobile", "E-Wallet", "Games")
    var selectedTab by remember { mutableStateOf("Mobile") }

    val telcos = listOf("Smart", "Globe", "DITO", "TNT")
    var selectedTelco by remember { mutableStateOf("Smart") }

    var phoneNumber by remember { mutableStateOf("0918 123 4567") }
    var selectedAmount by remember { mutableStateOf(100.0) }
    var cashInChannel by remember { mutableStateOf("BPI Online") }

    val mobileAmounts = listOf(50.0, 100.0, 200.0, 500.0, 1000.0)
    val gameTitles = listOf("Mobile Legends: 100 💎", "Valorant: 1,000 VP", "Steam Wallet ₱500", "Roblox: 800 Robux")
    var selectedGame by remember { mutableStateOf(gameTitles.first()) }

    DigiCashBackdrop {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Top Up & Load",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Tabs (Mobile, E-Wallet, Games)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0A1F3A))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                tabs.forEach { tab ->
                    val isSelected = selectedTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) CyanNeon else Color.Transparent)
                            .clickable { selectedTab = tab }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color(0xFF00222B) else TextSecondary
                        )
                    }
                }
            }

            if (selectedTab == "Mobile") {
                // Telco selection
                Text(
                    text = "Mobile Network",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    telcos.forEach { telco ->
                        val isSelected = selectedTelco == telco
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF133660) else Color(0xFF091C35))
                                .border(
                                    1.dp,
                                    if (isSelected) CyanNeon else CardBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedTelco = telco }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = telco,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) CyanNeon else Color.White
                            )
                        }
                    }
                }

                // Phone Input Card
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 18.dp,
                    backgroundColor = Color(0xCC0D2240)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Enter Mobile Number",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            placeholder = { Text("09XX XXX XXXX", color = TextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = CyanNeon)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )
                    }
                }

                // Select Amount
                Text(
                    text = "Select Load Amount",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    mobileAmounts.chunked(3).forEach { rowAmounts ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowAmounts.forEach { amt ->
                                val isSelected = selectedAmount == amt
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (isSelected) CyanNeon.copy(alpha = 0.2f) else Color(0xFF0C2444))
                                        .border(
                                            1.dp,
                                            if (isSelected) CyanNeon else CardBorder,
                                            RoundedCornerShape(14.dp)
                                        )
                                        .clickable { selectedAmount = amt }
                                        .padding(vertical = 14.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "₱ ${amt.toInt()}",
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) CyanNeon else Color.White
                                        )
                                        Text(
                                            text = "Regular",
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                            if (rowAmounts.size < 3) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                // Top Up Button
                Button(
                    onClick = {
                        if (phoneNumber.length < 10) {
                            Toast.makeText(context, "Enter valid 11-digit mobile number", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        onBuyLoad(phoneNumber, selectedTelco, selectedAmount)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(listOf(CyanBright, EmeraldMint)),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Top Up ₱${selectedAmount.toInt()}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00222B)
                        )
                    }
                }
            } else if (selectedTab == "E-Wallet") {
                // E-Wallet Cash In
                Text(
                    text = "Cash In to DigiCash Wallet",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                val cashInChannels = listOf("BPI Online", "BDO Direct", "UnionBank", "7-Eleven CLiQQ", "Over the Counter")
                cashInChannels.forEach { channel ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onCashIn(1000.0, channel)
                                Toast.makeText(context, "₱1,000 added via $channel", Toast.LENGTH_SHORT).show()
                            },
                        cornerRadius = 14.dp,
                        backgroundColor = Color(0xFF0C2445)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Wallet, contentDescription = null, tint = CyanNeon)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(channel, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                            Text("+ Cash In", color = EmeraldMint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                // Games
                Text(
                    text = "Gaming Pins & Credits",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                gameTitles.forEach { game ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onBuyLoad("User Gamer ID", game, 250.0)
                            },
                        cornerRadius = 14.dp,
                        backgroundColor = Color(0xFF0C2445)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.SportsEsports, contentDescription = null, tint = PurpleNeon)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(game, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                            Text("Buy", color = CyanNeon, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
