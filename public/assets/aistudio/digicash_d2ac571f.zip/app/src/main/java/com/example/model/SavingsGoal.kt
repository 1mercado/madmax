package com.example.model

data class SavingsGoal(
    val id: String,
    val title: String,
    val category: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val interestRatePA: Double = 6.0,
    val deadlineDate: String = "No deadline",
    val colorHex: Long = 0xFF00E5FF
) {
    val progress: Float
        get() = if (targetAmount > 0) (currentAmount / targetAmount).toFloat().coerceIn(0f, 1f) else 0f

    val progressPercent: Int
        get() = (progress * 100).toInt()

    val remainingAmount: Double
        get() = (targetAmount - currentAmount).coerceAtLeast(0.0)

    val isGoalReached: Boolean
        get() = currentAmount >= targetAmount
}
