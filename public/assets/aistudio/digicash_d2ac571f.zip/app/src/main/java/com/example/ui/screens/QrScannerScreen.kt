package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.Transaction
import com.example.model.UserProfile
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

data class ScannedQrPayload(
    val recipientName: String,
    val identifier: String,
    val suggestedAmount: Double,
    val note: String,
    val isMerchant: Boolean
)

@Composable
fun QrScannerScreen(
    userProfile: UserProfile,
    onBack: () -> Unit,
    onPaymentConfirmed: (recipient: String, amount: Double, note: String) -> Unit,
    onOpenMyQr: () -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (!isGranted) {
            Toast.makeText(context, "Camera permission optional. Simulation mode active.", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var isFlashOn by remember { mutableStateOf(false) }
    var activeScannedPayload by remember { mutableStateOf<ScannedQrPayload?>(null) }
    var showCustomQrDialog by remember { mutableStateOf(false) }

    // Laser scan animation
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserYRatio by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    // Preloaded sample QR Ph payloads for quick one-tap testing
    val sampleQrList = listOf(
        ScannedQrPayload("Maria Cruz", "+63 917 234 5678", 500.0, "Dinner split", false),
        ScannedQrPayload("Starbucks Coffee (QR Ph)", "MER-98231", 215.0, "Iced Latte", true),
        ScannedQrPayload("7-Eleven Store #412", "MER-71109", 145.0, "Quick Grocery", true),
        ScannedQrPayload("Carlo Mendoza", "+63 918 345 6789", 1200.0, "Monthly contribution", false)
    )

    DigiCashBackdrop {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0x990A1B33))
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "Scan QR Ph Code",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    // Flashlight toggle
                    IconButton(
                        onClick = {
                            isFlashOn = !isFlashOn
                            Toast.makeText(context, if (isFlashOn) "Torch ON" else "Torch OFF", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (isFlashOn) CyanNeon else Color(0x990A1B33))
                    ) {
                        Icon(
                            imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Flashlight",
                            tint = if (isFlashOn) Color.Black else Color.White
                        )
                    }
                }

                // Viewfinder Framing Canvas with sweeping laser
                Box(
                    modifier = Modifier
                        .size(280.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x40000000)),
                    contentAlignment = Alignment.Center
                ) {
                    // Viewfinder corners and sweeping laser
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 5.dp.toPx()
                        val cornerLen = 32.dp.toPx()
                        val cornerColor = if (isFlashOn) Color.White else CyanNeon

                        // Top-Left corner
                        drawLine(cornerColor, Offset(0f, 0f), Offset(cornerLen, 0f), strokeWidth)
                        drawLine(cornerColor, Offset(0f, 0f), Offset(0f, cornerLen), strokeWidth)

                        // Top-Right corner
                        drawLine(cornerColor, Offset(size.width, 0f), Offset(size.width - cornerLen, 0f), strokeWidth)
                        drawLine(cornerColor, Offset(size.width, 0f), Offset(size.width, cornerLen), strokeWidth)

                        // Bottom-Left corner
                        drawLine(cornerColor, Offset(0f, size.height), Offset(cornerLen, size.height), strokeWidth)
                        drawLine(cornerColor, Offset(0f, size.height), Offset(0f, size.height - cornerLen), strokeWidth)

                        // Bottom-Right corner
                        drawLine(cornerColor, Offset(size.width, size.height), Offset(size.width - cornerLen, size.height), strokeWidth)
                        drawLine(cornerColor, Offset(size.width, size.height), Offset(size.width, size.height - cornerLen), strokeWidth)

                        // Center Grid Reticle
                        drawRoundRect(
                            color = Color(0x2200E5FF),
                            topLeft = Offset(size.width * 0.1f, size.height * 0.1f),
                            size = Size(size.width * 0.8f, size.height * 0.8f),
                            cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
                            style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f))
                        )

                        // Animated Sweeping Laser line
                        val laserY = size.height * laserYRatio
                        drawLine(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, EmeraldMint, CyanNeon, EmeraldMint, Color.Transparent)
                            ),
                            start = Offset(size.width * 0.05f, laserY),
                            end = Offset(size.width * 0.95f, laserY),
                            strokeWidth = 3.dp.toPx()
                        )
                    }

                    // Instruction label inside viewfinder
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Align QR Ph code within frame",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.9f),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Quick Scan Simulators & Action Utilities
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Instant Test Targets (Tap to simulate scan):",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )

                    // 4 Quick Sample QR targets
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        sampleQrList.take(2).forEach { sample ->
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { activeScannedPayload = sample },
                                cornerRadius = 14.dp,
                                backgroundColor = Color(0xBB0D2345),
                                borderColor = CyanNeon.copy(alpha = 0.4f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (sample.isMerchant) Icons.Default.Storefront else Icons.Default.Person,
                                            contentDescription = null,
                                            tint = if (sample.isMerchant) PurpleNeon else CyanNeon,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(sample.recipientName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Text(sample.identifier, fontSize = 11.sp, color = TextSecondary)
                                        }
                                    }

                                    Text(
                                        text = "₱ %.2f".format(sample.suggestedAmount),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = EmeraldGreen
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Utility Bar (My QR & Custom Code)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onOpenMyQr,
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanNeon),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
                        ) {
                            Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("My QR Code", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showCustomQrDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanNeon,
                                contentColor = Color(0xFF00222B)
                            )
                        ) {
                            Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Enter Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Payment Confirmation Bottom Sheet / Dialog
            activeScannedPayload?.let { payload ->
                PaymentConfirmationDialog(
                    payload = payload,
                    userBalance = userProfile.balance,
                    onDismiss = { activeScannedPayload = null },
                    onConfirmPayment = { amt, note ->
                        onPaymentConfirmed(payload.recipientName, amt, note)
                        activeScannedPayload = null
                    }
                )
            }

            // Custom QR Code Manual Entry Dialog
            if (showCustomQrDialog) {
                var manualInput by remember { mutableStateOf("0919 888 7766") }
                var manualAmt by remember { mutableStateOf("250") }

                AlertDialog(
                    onDismissRequest = { showCustomQrDialog = false },
                    containerColor = Color(0xFF091C36),
                    title = {
                        Text(
                            text = "Manual QR Ph Entry",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "Enter DigiCash ID, Phone number, or Merchant Code:",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            OutlinedTextField(
                                value = manualInput,
                                onValueChange = { manualInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanNeon,
                                    unfocusedBorderColor = CardBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                            OutlinedTextField(
                                value = manualAmt,
                                onValueChange = { manualAmt = it },
                                label = { Text("Amount (₱)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanNeon,
                                    unfocusedBorderColor = CardBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val amt = manualAmt.toDoubleOrNull() ?: 100.0
                                activeScannedPayload = ScannedQrPayload(
                                    recipientName = manualInput,
                                    identifier = manualInput,
                                    suggestedAmount = amt,
                                    note = "Manual QR Ph transfer",
                                    isMerchant = false
                                )
                                showCustomQrDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF00222B))
                        ) {
                            Text("Confirm Target")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCustomQrDialog = false }) {
                            Text("Cancel", color = TextSecondary)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun PaymentConfirmationDialog(
    payload: ScannedQrPayload,
    userBalance: Double,
    onDismiss: () -> Unit,
    onConfirmPayment: (amount: Double, note: String) -> Unit
) {
    var amountText by remember { mutableStateOf(payload.suggestedAmount.toInt().toString()) }
    var paymentNote by remember { mutableStateOf(payload.note) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF081C38),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(EmeraldMint.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (payload.isMerchant) Icons.Default.Storefront else Icons.Default.Person,
                        contentDescription = null,
                        tint = EmeraldMint,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (payload.isMerchant) "Merchant Payment" else "Send via QR Ph",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = payload.recipientName,
                        fontSize = 12.sp,
                        color = CyanNeon,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Wallet Balance indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Your Balance:", fontSize = 12.sp, color = TextSecondary)
                    Text(
                        "₱ " + String.format(java.util.Locale.US, "%,.2f", userBalance),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon
                    )
                }

                // Amount input
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Payment Amount") },
                    prefix = { Text("₱ ", color = CyanNeon, fontWeight = FontWeight.Bold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = CardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                // Note input
                OutlinedTextField(
                    value = paymentNote,
                    onValueChange = { paymentNote = it },
                    label = { Text("Note / Message") },
                    placeholder = { Text("What's this for?") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanNeon,
                        unfocusedBorderColor = CardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                // Free transfer notice
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0C2B4D))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = EmeraldMint,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Zero transfer fee via National QR Ph standard",
                        fontSize = 10.5.sp,
                        color = EmeraldMint
                    )
                }

                errorText?.let {
                    Text(it, color = ErrorRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt <= 0) {
                        errorText = "Enter a valid amount."
                        return@Button
                    }
                    if (amt > userBalance) {
                        errorText = "Insufficient wallet balance."
                        return@Button
                    }
                    onConfirmPayment(amt, paymentNote)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanNeon,
                    contentColor = Color(0xFF00222B)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Confirm & Pay", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
