package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CompensationMechanics
import com.example.model.NetworkMember
import com.example.model.UserProfile
import com.example.model.UserTier
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun ReferralScreen(
    userProfile: UserProfile,
    networkMembers: List<NetworkMember>,
    onBack: () -> Unit,
    onSimulateSubscription: (Int, String) -> Unit,
    onSimulateBuilderUpgrade: (Int, String) -> Unit,
    onOpenBuilderUpgrade: () -> Unit
) {
    val context = LocalContext.current
    var simLevel by remember { mutableStateOf(1) }
    var simName by remember { mutableStateOf("New Subscriber") }
    var showSimulateSheet by remember { mutableStateOf(false) }

    DigiCashBackdrop {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(bottom = 100.dp, top = 16.dp, start = 18.dp, end = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Referral Program",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Promotional Invite Banner
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 20.dp,
                    backgroundColor = Color(0xFF0C2448),
                    borderColor = CyanNeon
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = GoldYellow,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Invite Friends, Earn Rewards",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Share your referral link and earn up to 10 levels of unilevel commission when they subscribe!",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 17.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Referral link container
                        Text(
                            text = "Your Referral Link",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF07172E))
                                .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = userProfile.referralLink,
                                fontSize = 13.sp,
                                color = CyanNeon,
                                fontWeight = FontWeight.SemiBold
                            )

                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("DigiCash Link", userProfile.referralLink))
                                    Toast.makeText(context, "Referral link copied!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanNeon,
                                    contentColor = Color(0xFF00222B)
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Copy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Stats Row: Total Referrals & Total Earnings
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Referrals
                    GlassCard(
                        modifier = Modifier.weight(1f),
                        cornerRadius = 16.dp,
                        backgroundColor = Color(0xCC0D2240)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Total Referrals",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${userProfile.totalReferrals}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }

                    // Total Earnings
                    GlassCard(
                        modifier = Modifier.weight(1f),
                        cornerRadius = 16.dp,
                        backgroundColor = Color(0xCC0D2240)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Total Earnings",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "₱ " + String.format(java.util.Locale.US, "%,.2f", userProfile.totalEarnings),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldGreen
                            )
                        }
                    }
                }
            }

            // Compensation Simulator trigger button
            item {
                Button(
                    onClick = { showSimulateSheet = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF133863))
                ) {
                    Icon(imageVector = Icons.Default.AutoGraph, contentDescription = null, tint = CyanNeon)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Simulate 60/40 Split & Unilevel Tree",
                        color = CyanNeon,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            // Builder Upgrade Callout if currently Basic
            if (userProfile.tier == UserTier.BASIC) {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenBuilderUpgrade),
                        cornerRadius = 16.dp,
                        backgroundColor = Color(0xFF2C1E0A),
                        borderColor = GoldYellow
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Unlock Levels 4 to 10!",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldYellow
                                )
                                Text(
                                    text = "Upgrade to Builder Pack (₱5,000) to activate deep downline commissions.",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                            Button(
                                onClick = onOpenBuilderUpgrade,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldYellow, contentColor = Color.Black)
                            ) {
                                Text("Upgrade", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Unilevel Commission Levels Breakdown Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Referral Levels (10-Tier)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (userProfile.tier == UserTier.BASIC) "Levels 1-3 Active" else "All 10 Levels Active",
                        fontSize = 11.sp,
                        color = if (userProfile.tier == UserTier.BASIC) CyanNeon else EmeraldGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // 10-Level Breakdown Items
            items(CompensationMechanics.LEVEL_PERCENTAGES) { (level, pct) ->
                val isUnlocked = CompensationMechanics.isLevelUnlocked(level, userProfile.tier)
                val countAtLevel = networkMembers.count { it.level == level }

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 14.dp,
                    backgroundColor = if (isUnlocked) Color(0x990D2444) else Color(0x550B1729),
                    borderColor = if (isUnlocked) CardBorder else Color(0x1100E5FF)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isUnlocked) CyanNeon.copy(alpha = 0.2f) else Color(0xFF16253B)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "L$level",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUnlocked) CyanNeon else TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Level $level",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isUnlocked) Color.White else TextMuted
                                )
                                Text(
                                    text = if (isUnlocked) "$countAtLevel direct & downline members" else "Requires Builder Pack",
                                    fontSize = 10.sp,
                                    color = if (isUnlocked) TextSecondary else ErrorRed.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$pct%",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isUnlocked) EmeraldMint else TextMuted
                            )
                            if (!isUnlocked) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Locked",
                                    tint = TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Downline members list
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Recent Team Network",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            items(networkMembers) { member ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 14.dp,
                    backgroundColor = Color(0x990A1F3B)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = member.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(member.tier.badgeColorHex).copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = member.tier.title,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(member.tier.badgeColorHex)
                                    )
                                }
                            }
                            Text(
                                text = "Level ${member.level} • Joined ${member.joinedDate}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }

                        Text(
                            text = "Level ${member.level}",
                            fontSize = 12.sp,
                            color = CyanNeon,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Compensation Simulator Modal
        if (showSimulateSheet) {
            AlertDialog(
                onDismissRequest = { showSimulateSheet = false },
                containerColor = Color(0xFF091C36),
                title = {
                    Text(
                        text = "Compensation Simulator",
                        color = CyanNeon,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Simulate how subscriptions and upgrades distribute 60% up to VIP 1,2,3, 40% to subscriber, and unilevel commissions to you!",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Text("Select Referral Level (1-10):", fontSize = 12.sp, color = Color.White)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            (1..5).forEach { lvl ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (simLevel == lvl) CyanNeon else Color(0xFF132F52))
                                        .clickable { simLevel = lvl }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "L$lvl",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (simLevel == lvl) Color.Black else Color.White
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            (6..10).forEach { lvl ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (simLevel == lvl) CyanNeon else Color(0xFF132F52))
                                        .clickable { simLevel = lvl }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "L$lvl",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (simLevel == lvl) Color.Black else Color.White
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Simulation Action 1: ₱500 Subscription
                        Button(
                            onClick = {
                                onSimulateSubscription(simLevel, "Subscriber L$simLevel")
                                showSimulateSheet = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF00222B))
                        ) {
                            Text("Simulate ₱500 Subscription at L$simLevel", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Simulation Action 2: ₱5,000 Builder Upgrade
                        Button(
                            onClick = {
                                onSimulateBuilderUpgrade(simLevel, "Partner L$simLevel")
                                showSimulateSheet = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldMint, contentColor = Color(0xFF00222B))
                        ) {
                            Text("Simulate ₱5,000 Builder Upgrade at L$simLevel", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showSimulateSheet = false }) {
                        Text("Close", color = TextSecondary)
                    }
                }
            )
        }
    }
}
