package com.example.model

enum class UserTier(
    val title: String,
    val price: Double,
    val description: String,
    val badgeColorHex: Long
) {
    BASIC(
        title = "Basic",
        price = 500.0,
        description = "₱500 One-time Subscription • Level 1-3 Referral Commissions",
        badgeColorHex = 0xFF00E5FF
    ),
    BUILDER(
        title = "Builder",
        price = 5000.0,
        description = "₱5,000 Pack • Unlocks Levels 4-10 Commissions + Higher Earnings",
        badgeColorHex = 0xFF00D294
    ),
    VIP_1(
        title = "VIP 1",
        price = 1000.0,
        description = "₱1,000 Tier • Monthly Benefits • VIP Pool Split to Infinity",
        badgeColorHex = 0xFFFFB300
    ),
    VIP_2(
        title = "VIP 2",
        price = 5000.0,
        description = "₱5,000 Tier • Bigger Rewards • VIP Pool Split to Infinity",
        badgeColorHex = 0xFFFF9100
    ),
    VIP_3(
        title = "VIP 3",
        price = 10000.0,
        description = "₱10,000 Tier • Max Earnings • Dedicated Manager • VIP Pool Split to Infinity",
        badgeColorHex = 0xFFFF3D00
    )
}

data class UserProfile(
    val id: String = "09123456789",
    val name: String = "Alex Santos",
    val email: String = "alex@digicash.ph",
    val phone: String = "+63 912 345 6789",
    val balance: Double = 12450.00,
    val points: Int = 2500,
    val tier: UserTier = UserTier.BASIC,
    val referralCode: String = "AB123",
    val referralLink: String = "https://digicash.ph/r/AB123",
    val totalReferrals: Int = 128,
    val totalEarnings: Double = 8450.00
)
