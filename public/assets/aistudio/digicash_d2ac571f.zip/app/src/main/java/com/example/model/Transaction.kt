package com.example.model

enum class TransactionType {
    SEND_MONEY,
    RECEIVE_MONEY,
    PAY_BILLS,
    TOP_UP_LOAD,
    REFERRAL_COMMISSION,
    VIP_POOL_DISTRIBUTION,
    BUILDER_UPGRADE,
    SUBSCRIPTION_REBATE,
    REWARDS_REDEEM,
    VAULT_DEPOSIT,
    VAULT_WITHDRAW
}

enum class TransactionDirection {
    INCOMING,
    OUTGOING
}

data class Transaction(
    val id: String,
    val type: TransactionType,
    val title: String,
    val subtitle: String,
    val amount: Double,
    val direction: TransactionDirection,
    val date: String,
    val time: String,
    val referenceNumber: String,
    val status: String = "Completed",
    val fee: Double = 0.0,
    val recipientOrBiller: String = "",
    val breakdownNote: String = ""
)
