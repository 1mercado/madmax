package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DigiCashRepository {

    private val _userProfile = MutableStateFlow(
        UserProfile(
            id = "09123456789",
            name = "Alex Santos",
            email = "alex@digicash.ph",
            phone = "+63 912 345 6789",
            balance = 12450.00,
            points = 2500,
            tier = UserTier.BASIC,
            referralCode = "AB123",
            referralLink = "https://digicash.ph/r/AB123",
            totalReferrals = 128,
            totalEarnings = 8450.00
        )
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _transactions = MutableStateFlow<List<Transaction>>(
        listOf(
            Transaction(
                id = "TX-901",
                type = TransactionType.REFERRAL_COMMISSION,
                title = "Level 1 Unilevel Commission",
                subtitle = "From Maria Cruz (₱500 Subscription)",
                amount = 50.00,
                direction = TransactionDirection.INCOMING,
                date = "Today",
                time = "10:45 AM",
                referenceNumber = "REF-20261022-901",
                recipientOrBiller = "Maria Cruz",
                breakdownNote = "10% direct commission on ₱500"
            ),
            Transaction(
                id = "TX-902",
                type = TransactionType.SEND_MONEY,
                title = "Send to Express",
                subtitle = "To Juan Dela Cruz (GCash)",
                amount = 500.00,
                direction = TransactionDirection.OUTGOING,
                date = "Today",
                time = "09:30 AM",
                referenceNumber = "REF-20261022-902",
                recipientOrBiller = "Juan Dela Cruz (+63 917 888 1234)"
            ),
            Transaction(
                id = "TX-903",
                type = TransactionType.PAY_BILLS,
                title = "Meralco Electric Bill",
                subtitle = "Account #109283746",
                amount = 2850.00,
                direction = TransactionDirection.OUTGOING,
                date = "Yesterday",
                time = "03:15 PM",
                referenceNumber = "REF-20261021-903",
                recipientOrBiller = "MERALCO"
            ),
            Transaction(
                id = "TX-904",
                type = TransactionType.REFERRAL_COMMISSION,
                title = "Level 2 Unilevel Commission",
                subtitle = "From Kevin Tan (₱500 Subscription)",
                amount = 25.00,
                direction = TransactionDirection.INCOMING,
                date = "Yesterday",
                time = "11:20 AM",
                referenceNumber = "REF-20261021-904",
                recipientOrBiller = "Kevin Tan",
                breakdownNote = "5% unilevel commission on ₱500"
            ),
            Transaction(
                id = "TX-905",
                type = TransactionType.TOP_UP_LOAD,
                title = "Regular Load ₱100",
                subtitle = "Smart Prepaid (+63 918 123 4567)",
                amount = 100.00,
                direction = TransactionDirection.OUTGOING,
                date = "20 Oct",
                time = "08:12 PM",
                referenceNumber = "REF-20261020-905",
                recipientOrBiller = "Smart Communications"
            ),
            Transaction(
                id = "TX-906",
                type = TransactionType.RECEIVE_MONEY,
                title = "Received via QR Ph",
                subtitle = "From Bianca Reyes",
                amount = 3200.00,
                direction = TransactionDirection.INCOMING,
                date = "19 Oct",
                time = "04:50 PM",
                referenceNumber = "REF-20261019-906",
                recipientOrBiller = "Bianca Reyes"
            )
        )
    )
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _networkMembers = MutableStateFlow<List<NetworkMember>>(
        listOf(
            NetworkMember("M-101", "Maria Cruz", "+63 917 234 5678", 1, UserTier.BASIC, "Oct 22, 2026", 50.0),
            NetworkMember("M-102", "Carlo Mendoza", "+63 918 345 6789", 1, UserTier.BUILDER, "Oct 21, 2026", 550.0),
            NetworkMember("M-103", "Elena Rostova", "+63 920 456 7890", 1, UserTier.BASIC, "Oct 19, 2026", 50.0),
            NetworkMember("M-201", "Kevin Tan", "+63 919 567 8901", 2, UserTier.BASIC, "Oct 21, 2026", 25.0),
            NetworkMember("M-202", "Samantha Lim", "+63 927 678 9012", 2, UserTier.BUILDER, "Oct 20, 2026", 275.0),
            NetworkMember("M-301", "David Go", "+63 916 789 0123", 3, UserTier.BASIC, "Oct 18, 2026", 20.0),
            NetworkMember("M-401", "Rhea Morales", "+63 922 890 1234", 4, UserTier.BASIC, "Oct 17, 2026", 15.0),
            NetworkMember("M-501", "Joel Bautista", "+63 925 901 2345", 5, UserTier.BASIC, "Oct 15, 2026", 10.0)
        )
    )
    val networkMembers: StateFlow<List<NetworkMember>> = _networkMembers.asStateFlow()

    val billers = listOf(
        Biller("b1", "MERALCO", "Electricity", "Manila Electric Company", 0.0, "MER"),
        Biller("b2", "Maynilad", "Water", "Maynilad Water Services", 0.0, "MYN"),
        Biller("b3", "Manila Water", "Water", "Manila Water Company", 0.0, "MWC"),
        Biller("b4", "PLDT Home", "Internet", "PLDT Landline & Fiber", 0.0, "PLDT"),
        Biller("b5", "Globe At Home", "Internet", "Globe Postpaid & Broadband", 0.0, "GLB"),
        Biller("b6", "Converge ICT", "Internet", "Converge FiberX", 0.0, "CNV"),
        Biller("b7", "Sky Cable", "Cable TV", "Sky Cable & Broadband", 0.0, "SKY"),
        Biller("b8", "Cignal TV", "Cable TV", "Cignal Postpaid / Prepaid", 0.0, "CIG"),
        Biller("b9", "SSS Contributions", "Government", "Social Security System", 10.0, "SSS"),
        Biller("b10", "PhilHealth", "Government", "Philippine Health Insurance", 10.0, "PHL"),
        Biller("b11", "Pag-IBIG Fund", "Government", "Home Development Mutual Fund", 10.0, "HDMF"),
        Biller("b12", "Home Credit", "Loans", "Home Credit Installments", 15.0, "HCD")
    )

    val rewardsList = listOf(
        RewardItem(
            id = "rw1",
            title = "₱50 Cash Voucher",
            description = "Instant ₱50 cash credited directly to your DigiCash wallet.",
            pointsCost = 2500,
            category = "Cash",
            rewardValueFormatted = "₱50.00",
            cashCreditAmount = 50.0
        ),
        RewardItem(
            id = "rw2",
            title = "Free Load ₱100",
            description = "Get ₱100 free mobile prepaid load voucher code.",
            pointsCost = 1000,
            category = "Load",
            rewardValueFormatted = "₱100.00",
            cashCreditAmount = 100.0
        ),
        RewardItem(
            id = "rw3",
            title = "Shopping Discount ₱1,000",
            description = "Special e-commerce discount voucher for partner merchants.",
            pointsCost = 5000,
            category = "Shopping",
            rewardValueFormatted = "₱1,000 OFF",
            cashCreditAmount = 0.0
        ),
        RewardItem(
            id = "rw4",
            title = "Exclusive Item & Merch",
            description = "DigiCash Worldwide VIP metallic cardholder & premium cap.",
            pointsCost = 10000,
            category = "Exclusive",
            rewardValueFormatted = "VIP Merch",
            cashCreditAmount = 0.0
        )
    )

    private fun getCurrentDateFormatted(): String {
        return SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date())
    }

    private fun getCurrentTimeFormatted(): String {
        return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
    }

    private fun generateRef(): String {
        return "REF-" + UUID.randomUUID().toString().substring(0, 8).uppercase(Locale.ROOT)
    }

    fun sendMoney(
        recipient: String,
        amount: Double,
        channel: String,
        note: String
    ): Result<Transaction> {
        val current = _userProfile.value
        if (amount <= 0) return Result.failure(Exception("Amount must be greater than zero."))
        if (current.balance < amount) return Result.failure(Exception("Insufficient wallet balance."))

        val newBalance = current.balance - amount
        val earnedPoints = (amount / 50.0).toInt().coerceAtLeast(5) // Earn loyalty points on send
        _userProfile.value = current.copy(
            balance = newBalance,
            points = current.points + earnedPoints
        )

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.SEND_MONEY,
            title = "Sent via $channel",
            subtitle = "To $recipient",
            amount = amount,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = recipient,
            breakdownNote = if (note.isNotBlank()) "Note: $note (+$earnedPoints pts)" else "+$earnedPoints loyalty points"
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success(tx)
    }

    fun payBill(biller: Biller, accountNumber: String, amount: Double): Result<Transaction> {
        val current = _userProfile.value
        val totalDebit = amount + biller.fee
        if (amount <= 0) return Result.failure(Exception("Amount must be greater than zero."))
        if (current.balance < totalDebit) return Result.failure(Exception("Insufficient balance for bill payment."))

        val newBalance = current.balance - totalDebit
        val pointsEarned = (amount / 40.0).toInt().coerceAtLeast(10)
        _userProfile.value = current.copy(
            balance = newBalance,
            points = current.points + pointsEarned
        )

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.PAY_BILLS,
            title = "${biller.name} Payment",
            subtitle = "Account: $accountNumber",
            amount = totalDebit,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = biller.name,
            fee = biller.fee,
            breakdownNote = "Bill: ₱%.2f, Fee: ₱%.2f (+$pointsEarned pts)".format(amount, biller.fee)
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success(tx)
    }

    fun buyLoad(phone: String, telco: String, amount: Double): Result<Transaction> {
        val current = _userProfile.value
        if (amount <= 0) return Result.failure(Exception("Select a valid load denomination."))
        if (current.balance < amount) return Result.failure(Exception("Insufficient wallet balance."))

        val newBalance = current.balance - amount
        val points = (amount / 20.0).toInt().coerceAtLeast(2)
        _userProfile.value = current.copy(
            balance = newBalance,
            points = current.points + points
        )

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.TOP_UP_LOAD,
            title = "$telco Load ₱${amount.toInt()}",
            subtitle = "Recipient: $phone",
            amount = amount,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "$telco ($phone)",
            breakdownNote = "Instant load delivered (+$points pts)"
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success(tx)
    }

    fun receiveMoney(sender: String, amount: Double, note: String): Transaction {
        val current = _userProfile.value
        val newBalance = current.balance + amount
        _userProfile.value = current.copy(balance = newBalance)

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.RECEIVE_MONEY,
            title = "Received Money",
            subtitle = "From $sender",
            amount = amount,
            direction = TransactionDirection.INCOMING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = sender,
            breakdownNote = note
        )
        _transactions.value = listOf(tx) + _transactions.value
        return tx
    }

    /**
     * Executes the exact Compensation Mechanics for BUILDER UPGRADE:
     * - Upgrade cost: ₱5,000
     * - 60% (₱3,000) splits up to VIP 1, 2, and 3 (₱1,000 each)
     * - 40% (₱2,000) remains in subscriber's wallet as upgrade cashback rebate!
     * - Unlocks Level 4 to 10 Unilevel Commissions!
     */
    fun upgradeToBuilder(): Result<SplitBreakdown> {
        val current = _userProfile.value
        val cost = CompensationMechanics.BUILDER_UPGRADE_AMOUNT
        if (current.tier != UserTier.BASIC) {
            return Result.failure(Exception("You have already upgraded past Basic tier!"))
        }
        if (current.balance < cost) {
            return Result.failure(Exception("Insufficient balance (₱${"%.2f".format(cost)} required). Please top up or receive funds."))
        }

        val split = CompensationMechanics.calculateSplit(cost)
        // Deduct ₱5,000 and immediately credit back 40% (₱2,000) -> Net deduction is ₱3,000 (which went to VIP pool)
        val netDeduction = split.vipPoolTotal
        val newBalance = current.balance - netDeduction

        _userProfile.value = current.copy(
            tier = UserTier.BUILDER,
            balance = newBalance
        )

        // Add 2 transaction records: The Upgrade payment and the 40% Cashback rebate
        val upgradeTx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.BUILDER_UPGRADE,
            title = "Builder Pack Upgrade",
            subtitle = "Unlocked Levels 4 to 10 Commissions",
            amount = cost,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "DigiCash Worldwide",
            breakdownNote = "60% (₱3,000) distributed to VIP 1, 2, 3 Pool"
        )

        val rebateTx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.SUBSCRIPTION_REBATE,
            title = "Builder 40% Wallet Cashback",
            subtitle = "Instant Rebate Credited",
            amount = split.subscriberCashback,
            direction = TransactionDirection.INCOMING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "DigiCash Rebate System",
            breakdownNote = "40% retained in subscriber wallet (₱2,000.00)"
        )

        _transactions.value = listOf(rebateTx, upgradeTx) + _transactions.value
        return Result.success(split)
    }

    /**
     * VIP Upgrade (VIP 1: ₱1,000, VIP 2: ₱5,000, VIP 3: ₱10,000)
     */
    fun upgradeToVip(targetTier: UserTier): Result<String> {
        val current = _userProfile.value
        val cost = targetTier.price
        if (current.balance < cost) {
            return Result.failure(Exception("Insufficient balance for ${targetTier.title}."))
        }

        val newBalance = current.balance - cost
        _userProfile.value = current.copy(
            tier = targetTier,
            balance = newBalance
        )

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.BUILDER_UPGRADE,
            title = "${targetTier.title} Membership Activated",
            subtitle = "VIP Infinite Pool Share Unlocked",
            amount = cost,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "DigiCash VIP Club",
            breakdownNote = targetTier.description
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success("Successfully upgraded to ${targetTier.title}!")
    }

    /**
     * Simulates a new member subscribing (₱500 one-time) in the user's unilevel tree:
     * - 60% (₱300) split across VIP 1, 2, and 3
     * - 40% (₱200) remains in the subscriber's wallet
     * - If our user is eligible at `level`, user receives the exact commission %:
     *   L1: 10% (₱50)
     *   L2: 5% (₱25)
     *   L3: 4% (₱20)
     *   (L4-10 unlocked if Builder/VIP): L4 3%, L5 2%, L6 1.5%, L7 1%, L8 0.75%, L9 0.5%, L10 0.25%
     */
    fun simulateNewSubscriber(level: Int, subscriberName: String): SimulationResult {
        val current = _userProfile.value
        val subscriptionAmount = CompensationMechanics.BASIC_SUBSCRIPTION_AMOUNT
        val split = CompensationMechanics.calculateSplit(subscriptionAmount)

        val isUnlocked = CompensationMechanics.isLevelUnlocked(level, current.tier)
        val commission = if (isUnlocked) {
            CompensationMechanics.calculateCommission(subscriptionAmount, level)
        } else {
            0.0
        }

        if (commission > 0) {
            _userProfile.value = current.copy(
                balance = current.balance + commission,
                totalReferrals = current.totalReferrals + 1,
                totalEarnings = current.totalEarnings + commission
            )

            val tx = Transaction(
                id = "TX-" + UUID.randomUUID().toString().take(6),
                type = TransactionType.REFERRAL_COMMISSION,
                title = "Level $level Unilevel Commission",
                subtitle = "From $subscriberName (₱500 Subscription)",
                amount = commission,
                direction = TransactionDirection.INCOMING,
                date = "Today",
                time = getCurrentTimeFormatted(),
                referenceNumber = generateRef(),
                recipientOrBiller = subscriberName,
                breakdownNote = "%.1f%% unilevel commission on ₱500".format(commission / subscriptionAmount * 100)
            )
            _transactions.value = listOf(tx) + _transactions.value
        } else {
            _userProfile.value = current.copy(
                totalReferrals = current.totalReferrals + 1
            )
        }

        // Add to downline list
        val newMember = NetworkMember(
            id = "M-" + UUID.randomUUID().toString().take(4),
            name = subscriberName,
            phone = "+63 9${(10..99).random()} ${(100..999).random()} ${(1000..9999).random()}",
            level = level,
            tier = UserTier.BASIC,
            joinedDate = "Just now",
            earningsGenerated = commission
        )
        _networkMembers.value = listOf(newMember) + _networkMembers.value

        return SimulationResult(
            eventName = "₱500 Subscription",
            subscriberName = subscriberName,
            level = level,
            amount = subscriptionAmount,
            split = split,
            commissionEarned = commission,
            isUnlocked = isUnlocked
        )
    }

    /**
     * Simulates a downline member upgrading to BUILDER PACK (₱5,000):
     * - 60% (₱3,000) split across VIP 1, 2, 3
     * - 40% (₱2,000) remains in member's wallet
     * - Commission earned based on level if unlocked!
     */
    fun simulateDownlineBuilderUpgrade(level: Int, memberName: String): SimulationResult {
        val current = _userProfile.value
        val upgradeAmount = CompensationMechanics.BUILDER_UPGRADE_AMOUNT
        val split = CompensationMechanics.calculateSplit(upgradeAmount)

        val isUnlocked = CompensationMechanics.isLevelUnlocked(level, current.tier)
        val commission = if (isUnlocked) {
            CompensationMechanics.calculateCommission(upgradeAmount, level)
        } else {
            0.0
        }

        if (commission > 0) {
            _userProfile.value = current.copy(
                balance = current.balance + commission,
                totalEarnings = current.totalEarnings + commission
            )

            val tx = Transaction(
                id = "TX-" + UUID.randomUUID().toString().take(6),
                type = TransactionType.REFERRAL_COMMISSION,
                title = "Level $level Builder Commission",
                subtitle = "From $memberName (₱5,000 Upgrade)",
                amount = commission,
                direction = TransactionDirection.INCOMING,
                date = "Today",
                time = getCurrentTimeFormatted(),
                referenceNumber = generateRef(),
                recipientOrBiller = memberName,
                breakdownNote = "%.1f%% unilevel commission on ₱5,000".format(commission / upgradeAmount * 100)
            )
            _transactions.value = listOf(tx) + _transactions.value
        }

        return SimulationResult(
            eventName = "₱5,000 Builder Upgrade",
            subscriberName = memberName,
            level = level,
            amount = upgradeAmount,
            split = split,
            commissionEarned = commission,
            isUnlocked = isUnlocked
        )
    }

    fun claimDailyPoints(): Result<Int> {
        val current = _userProfile.value
        val dailyReward = 50
        _userProfile.value = current.copy(points = current.points + dailyReward)
        return Result.success(dailyReward)
    }

    fun redeemReward(item: RewardItem): Result<String> {
        val current = _userProfile.value
        if (current.points < item.pointsCost) {
            return Result.failure(Exception("Insufficient points (${item.pointsCost} required, you have ${current.points})."))
        }

        val newPoints = current.points - item.pointsCost
        val newBalance = current.balance + item.cashCreditAmount

        _userProfile.value = current.copy(
            points = newPoints,
            balance = newBalance
        )

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.REWARDS_REDEEM,
            title = "Reward Redeemed: ${item.title}",
            subtitle = "Cost: ${item.pointsCost} points",
            amount = item.cashCreditAmount,
            direction = if (item.cashCreditAmount > 0) TransactionDirection.INCOMING else TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "DigiCash Rewards",
            breakdownNote = if (item.cashCreditAmount > 0) "₱${item.cashCreditAmount.toInt()} added to wallet!" else "Voucher delivered"
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success("Redeemed ${item.title} successfully!")
    }

    // Top up / cash-in to user wallet
    fun cashIn(amount: Double, channel: String): Transaction {
        val current = _userProfile.value
        _userProfile.value = current.copy(balance = current.balance + amount)

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.RECEIVE_MONEY,
            title = "Cash-In via $channel",
            subtitle = "Wallet Credited",
            amount = amount,
            direction = TransactionDirection.INCOMING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = channel
        )
        _transactions.value = listOf(tx) + _transactions.value
        return tx
    }

    // ==========================================
    // SAVINGS VAULT SYSTEM (HIGH-YIELD 6.0% P.A.)
    // ==========================================
    private val _savingsGoals = MutableStateFlow<List<SavingsGoal>>(
        listOf(
            SavingsGoal(
                id = "SG-1",
                title = "Emergency Fund",
                category = "Emergency",
                targetAmount = 25000.0,
                currentAmount = 14500.0,
                interestRatePA = 6.0,
                deadlineDate = "31 Dec 2026",
                colorHex = 0xFF00E5FF
            ),
            SavingsGoal(
                id = "SG-2",
                title = "Builder Pack Upgrade",
                category = "Investment",
                targetAmount = 5000.0,
                currentAmount = 3500.0,
                interestRatePA = 6.0,
                deadlineDate = "15 Nov 2026",
                colorHex = 0xFF00D294
            ),
            SavingsGoal(
                id = "SG-3",
                title = "Holiday & Travel Trip",
                category = "Travel",
                targetAmount = 15000.0,
                currentAmount = 4500.0,
                interestRatePA = 6.0,
                deadlineDate = "25 Dec 2026",
                colorHex = 0xFFFFB300
            )
        )
    )
    val savingsGoals: StateFlow<List<SavingsGoal>> = _savingsGoals.asStateFlow()

    fun createSavingsGoal(
        title: String,
        category: String,
        targetAmount: Double,
        initialDeposit: Double,
        colorHex: Long = 0xFF00E5FF
    ): Result<SavingsGoal> {
        val currentProfile = _userProfile.value
        if (targetAmount <= 0) return Result.failure(Exception("Target amount must be greater than zero."))
        if (initialDeposit > currentProfile.balance) return Result.failure(Exception("Insufficient wallet balance for initial deposit."))

        if (initialDeposit > 0) {
            _userProfile.value = currentProfile.copy(balance = currentProfile.balance - initialDeposit)
            val tx = Transaction(
                id = "TX-" + UUID.randomUUID().toString().take(6),
                type = TransactionType.VAULT_DEPOSIT,
                title = "Vault Deposit: $title",
                subtitle = "Initial Savings Goal Funding",
                amount = initialDeposit,
                direction = TransactionDirection.OUTGOING,
                date = "Today",
                time = getCurrentTimeFormatted(),
                referenceNumber = generateRef(),
                recipientOrBiller = "Savings Vault ($title)",
                breakdownNote = "Earning 6.0% p.a. daily interest"
            )
            _transactions.value = listOf(tx) + _transactions.value
        }

        val newGoal = SavingsGoal(
            id = "SG-" + UUID.randomUUID().toString().take(4),
            title = title,
            category = category,
            targetAmount = targetAmount,
            currentAmount = initialDeposit,
            interestRatePA = 6.0,
            deadlineDate = "Flexible",
            colorHex = colorHex
        )

        _savingsGoals.value = _savingsGoals.value + newGoal
        return Result.success(newGoal)
    }

    fun depositToGoal(goalId: String, amount: Double): Result<Transaction> {
        val currentProfile = _userProfile.value
        if (amount <= 0) return Result.failure(Exception("Deposit amount must be greater than zero."))
        if (amount > currentProfile.balance) return Result.failure(Exception("Insufficient wallet balance."))

        val goalIndex = _savingsGoals.value.indexOfFirst { it.id == goalId }
        if (goalIndex == -1) return Result.failure(Exception("Goal not found."))

        val currentGoal = _savingsGoals.value[goalIndex]
        val updatedGoal = currentGoal.copy(currentAmount = currentGoal.currentAmount + amount)

        val updatedGoals = _savingsGoals.value.toMutableList()
        updatedGoals[goalIndex] = updatedGoal
        _savingsGoals.value = updatedGoals

        _userProfile.value = currentProfile.copy(balance = currentProfile.balance - amount)

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.VAULT_DEPOSIT,
            title = "Deposit to ${currentGoal.title}",
            subtitle = "Transferred from Wallet to Vault",
            amount = amount,
            direction = TransactionDirection.OUTGOING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "Vault: ${currentGoal.title}",
            breakdownNote = "Progress: ${updatedGoal.progressPercent}% of ₱${updatedGoal.targetAmount.toInt()}"
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success(tx)
    }

    fun withdrawFromGoal(goalId: String, amount: Double): Result<Transaction> {
        val currentProfile = _userProfile.value
        if (amount <= 0) return Result.failure(Exception("Withdrawal amount must be greater than zero."))

        val goalIndex = _savingsGoals.value.indexOfFirst { it.id == goalId }
        if (goalIndex == -1) return Result.failure(Exception("Goal not found."))

        val currentGoal = _savingsGoals.value[goalIndex]
        if (amount > currentGoal.currentAmount) return Result.failure(Exception("Amount exceeds saved goal balance (₱%.2f available).".format(currentGoal.currentAmount)))

        val updatedGoal = currentGoal.copy(currentAmount = currentGoal.currentAmount - amount)
        val updatedGoals = _savingsGoals.value.toMutableList()
        updatedGoals[goalIndex] = updatedGoal
        _savingsGoals.value = updatedGoals

        _userProfile.value = currentProfile.copy(balance = currentProfile.balance + amount)

        val tx = Transaction(
            id = "TX-" + UUID.randomUUID().toString().take(6),
            type = TransactionType.VAULT_WITHDRAW,
            title = "Withdrawal from ${currentGoal.title}",
            subtitle = "Transferred from Vault to Wallet",
            amount = amount,
            direction = TransactionDirection.INCOMING,
            date = "Today",
            time = getCurrentTimeFormatted(),
            referenceNumber = generateRef(),
            recipientOrBiller = "Wallet Balance",
            breakdownNote = "Remaining Goal Balance: ₱%.2f".format(updatedGoal.currentAmount)
        )
        _transactions.value = listOf(tx) + _transactions.value
        return Result.success(tx)
    }
}

data class SimulationResult(
    val eventName: String,
    val subscriberName: String,
    val level: Int,
    val amount: Double,
    val split: SplitBreakdown,
    val commissionEarned: Double,
    val isUnlocked: Boolean
)
