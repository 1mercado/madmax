package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.DigiCashDLogo
import com.example.ui.theme.*

/**
 * Splash Screen replicating the reference UI 100%:
 * - Luminous deep sapphire space backdrop (no black shroud)
 * - Centered 3D gradient D mark
 * - "DigiCash WORLDWIDE" branding with gradient accent
 * - "Your Money,\nMade Easier." tagline
 * - Glowing 3D Earth with illuminated continents and orbital network lines
 * - Pill "Get Started" gradient button & "Login" outlined cyan pill button
 */
@Composable
fun SplashScreen(
    onGetStarted: () -> Unit,
    onLoginClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF01142F), // Luminous deep sapphire
                        Color(0xFF021E44), // Rich ocean blue
                        Color(0xFF032654), // Mid space blue
                        Color(0xFF011736)  // Base deep cosmic navy
                    )
                )
            )
    ) {
        // Glowing Earth backdrop full cover the whole background
        Image(
            painter = painterResource(id = R.drawable.img_earth_backdrop),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Main Foreground Content centered in the middle
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 3D Gradient D Logo
            DigiCashDLogo(
                size = 92.dp,
                showGlow = true,
                primaryColor = Color(0xFF00E5FF),
                accentColor = Color(0xFF88F953)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // "DigiCash" with "Digi" in White and "Cash" in Bright Cyan-Mint
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Digi",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Cash",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF00F5A0),
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // "WORLDWIDE"
            Text(
                text = "WORLDWIDE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00E5FF),
                letterSpacing = 6.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Tagline: "Your Money,\nMade Easier."
            Text(
                text = "Your Money,",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Made Easier.",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F5A0),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Middle Center CTA Buttons
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // "Get Started" Pill Button
                Button(
                    onClick = onGetStarted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        Color(0xFF88F953), // Lime green
                                        Color(0xFF00F5A0), // Mint teal
                                        Color(0xFF00E5FF)  // Electric cyan
                                    )
                                ),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Get Started",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00222B)
                        )
                    }
                }

                // "Login" Outlined Pill Button
                OutlinedButton(
                    onClick = onLoginClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0x1800E5FF),
                        contentColor = Color(0xFF00E5FF)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.6.dp,
                        Color(0xFF00E5FF).copy(alpha = 0.85f)
                    ),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = "Login",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF)
                    )
                }
            }
        }
    }
}
