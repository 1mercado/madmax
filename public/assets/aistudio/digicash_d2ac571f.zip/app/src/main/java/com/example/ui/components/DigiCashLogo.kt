package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldMint

/**
 * Transparent vector D logo for DigiCash Worldwide.
 * Renders the signature speed bars and glowing modern D emblem with zero background box.
 */
@Composable
fun DigiCashDLogo(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showGlow: Boolean = false,
    primaryColor: Color = CyanNeon,
    accentColor: Color = EmeraldMint
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Optional ambient radial glow behind the emblem
            if (showGlow) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = 0.45f),
                            accentColor.copy(alpha = 0.15f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.55f, h * 0.5f),
                        radius = w * 0.65f
                    ),
                    radius = w * 0.65f,
                    center = Offset(w * 0.55f, h * 0.5f)
                )
            }

            val gradientBrush = Brush.linearGradient(
                colors = listOf(primaryColor, accentColor),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )

            // 1. Left Speed Bars (3 rounded pills)
            val barHeight = h * 0.08f
            val pillRadius = CornerRadius(barHeight / 2, barHeight / 2)

            // Top Bar
            drawRoundRect(
                brush = gradientBrush,
                topLeft = Offset(w * 0.08f, h * 0.28f),
                size = Size(w * 0.20f, barHeight),
                cornerRadius = pillRadius
            )

            // Middle Bar (longer)
            drawRoundRect(
                brush = gradientBrush,
                topLeft = Offset(w * 0.03f, h * 0.46f),
                size = Size(w * 0.28f, barHeight),
                cornerRadius = pillRadius
            )

            // Bottom Bar
            drawRoundRect(
                brush = gradientBrush,
                topLeft = Offset(w * 0.08f, h * 0.64f),
                size = Size(w * 0.20f, barHeight),
                cornerRadius = pillRadius
            )

            // 2. Main "D" Emblem with outer sweep and inner cutout (EvenOdd)
            val dPath = Path().apply {
                fillType = PathFillType.EvenOdd

                // Outer D loop
                val outerLeft = w * 0.38f
                val outerTop = h * 0.18f
                val outerRight = w * 0.94f
                val outerBottom = h * 0.82f
                val outerCorner = w * 0.06f

                // Top-left start with rounded corner
                moveTo(outerLeft + outerCorner, outerTop)
                // Top horizontal edge towards curve
                lineTo(w * 0.64f, outerTop)
                // Outer curve sweeping to apex and bottom
                cubicTo(
                    w * 0.86f, outerTop,
                    outerRight, h * 0.34f,
                    outerRight, h * 0.50f
                )
                cubicTo(
                    outerRight, h * 0.66f,
                    w * 0.86f, outerBottom,
                    w * 0.64f, outerBottom
                )
                // Bottom horizontal edge back to spine
                lineTo(outerLeft + outerCorner, outerBottom)
                // Bottom-left rounded corner
                quadraticTo(outerLeft, outerBottom, outerLeft, outerBottom - outerCorner)
                // Vertical spine going up
                lineTo(outerLeft, outerTop + outerCorner)
                // Top-left rounded corner
                quadraticTo(outerLeft, outerTop, outerLeft + outerCorner, outerTop)
                close()

                // Inner Cutout
                val innerLeft = w * 0.52f
                val innerTop = h * 0.32f
                val innerRight = w * 0.79f
                val innerBottom = h * 0.68f
                val innerCorner = w * 0.03f

                moveTo(innerLeft + innerCorner, innerTop)
                lineTo(w * 0.63f, innerTop)
                cubicTo(
                    w * 0.75f, innerTop,
                    innerRight, h * 0.40f,
                    innerRight, h * 0.50f
                )
                cubicTo(
                    innerRight, h * 0.60f,
                    w * 0.75f, innerBottom,
                    w * 0.63f, innerBottom
                )
                lineTo(innerLeft + innerCorner, innerBottom)
                quadraticTo(innerLeft, innerBottom, innerLeft, innerBottom - innerCorner)
                lineTo(innerLeft, innerTop + innerCorner)
                quadraticTo(innerLeft, innerTop, innerLeft + innerCorner, innerTop)
                close()
            }

            drawPath(path = dPath, brush = gradientBrush)
        }
    }
}
