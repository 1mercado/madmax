package com.example.ui.components

import androidx.compose.runtime.Composable
import com.example.model.Transaction

/**
 * Backward-compatible delegator to [TransactionReceiptDialog].
 */
@Composable
fun ReceiptDialog(
    transaction: Transaction,
    onDismiss: () -> Unit
) {
    TransactionReceiptDialog(
        transaction = transaction,
        onDismiss = onDismiss
    )
}
