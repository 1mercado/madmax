package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Transaction
import com.example.model.TransactionDirection
import com.example.model.UserProfile
import com.example.model.UserTier
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.DigiCashBalanceCard
import com.example.ui.components.DigiCashDLogo
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    userProfile: UserProfile,
    recentTransactions: List<Transaction>,
    onSendClick: () -> Unit,
    onReceiveClick: () -> Unit,
    onScanQrClick: () -> Unit,
    onPayBillsClick: () -> Unit,
    onTopUpClick: () -> Unit,
    onRewardsClick: () -> Unit,
    onReferralClick: () -> Unit,
    onBuilderClick: () -> Unit,
    onVipClick: () -> Unit,
    savingsGoals: List<com.example.model.SavingsGoal> = emptyList(),
    onSavingsVaultClick: () -> Unit = {},
    onTransactionClick: (Transaction) -> Unit,
    onViewAllTransactions: () -> Unit,
    onProfileClick: () -> Unit
) {
    DigiCashBackdrop {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(bottom = 100.dp, top = 16.dp, start = 18.dp, end = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        DigiCashDLogo(
                            size = 40.dp,
                            showGlow = true
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "DigiCash",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "WORLDWIDE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanNeon,
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "Good day, ${userProfile.name}!",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // Avatar & Tier Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F2647))
                            .clickable(onClick = onProfileClick)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(userProfile.tier.badgeColorHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = userProfile.name.take(1),
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = userProfile.tier.title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(userProfile.tier.badgeColorHex)
                        )
                    }
                }
            }

            // Transaction Dashboard with Balance, Tier Status, and Financial Activity Summary
            item {
                com.example.ui.components.TransactionDashboard(
                    userProfile = userProfile,
                    transactions = recentTransactions,
                    onSendClick = onSendClick,
                    onReceiveClick = onReceiveClick,
                    onScanQrClick = onScanQrClick,
                    onPayBillsClick = onPayBillsClick,
                    onTopUpClick = onTopUpClick,
                    onUpgradeTierClick = onBuilderClick,
                    onTransactionClick = onTransactionClick,
                    onViewAllClick = onViewAllTransactions
                )
            }

            // Quick Services Section
            item {
                Text(
                    text = "Quick Services",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(10.dp))

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 20.dp,
                    backgroundColor = Color(0xCC0B1E38)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            ServiceItem(
                                icon = Icons.Default.PhoneAndroid,
                                label = "Load",
                                color = CyanNeon,
                                onClick = onTopUpClick
                            )
                            ServiceItem(
                                icon = Icons.Default.ReceiptLong,
                                label = "Bills",
                                color = PurpleNeon,
                                onClick = onPayBillsClick
                            )
                            ServiceItem(
                                icon = Icons.Default.CardGiftcard,
                                label = "Rewards",
                                color = GoldYellow,
                                onClick = onRewardsClick
                            )
                            ServiceItem(
                                icon = Icons.Default.Group,
                                label = "Referrals",
                                color = EmeraldMint,
                                onClick = onReferralClick
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            ServiceItem(
                                icon = Icons.Default.RocketLaunch,
                                label = "Builder Pack",
                                color = CyanBright,
                                onClick = onBuilderClick
                            )
                            ServiceItem(
                                icon = Icons.Default.WorkspacePremium,
                                label = "VIP Club",
                                color = GoldYellow,
                                onClick = onVipClick
                            )
                            ServiceItem(
                                icon = Icons.Default.Savings,
                                label = "Savings",
                                color = EmeraldMint,
                                onClick = onSavingsVaultClick
                            )
                            ServiceItem(
                                icon = Icons.Default.QrCodeScanner,
                                label = "Scan QR",
                                color = Color(0xFFE040FB),
                                onClick = onScanQrClick
                            )
                        }
                    }
                }
            }

            // Savings Vault High-Yield Card
            item {
                com.example.ui.components.SavingsVaultWidget(
                    goals = savingsGoals,
                    onOpenVault = onSavingsVaultClick
                )
            }

            // Promotional Banner (Builder Upgrade / Referral Incentive)
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onBuilderClick),
                    cornerRadius = 18.dp,
                    backgroundColor = Color(0xFF092142),
                    borderColor = CyanNeon.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "BUILDER PACK • ₱5,000",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CyanNeon,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(EmeraldMint.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "40% REBATE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldGreen
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Unlock Levels 4 to 10 Unilevel commissions + instant ₱2,000 cashback!",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyanNeon),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Upgrade",
                                tint = Color(0xFF00222B),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }


        }
    }
}

@Composable
fun ServiceItem(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(color.copy(alpha = 0.15f))
                .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.White,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun TransactionListItem(
    transaction: Transaction,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        cornerRadius = 16.dp,
        backgroundColor = Color(0x990D213D)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (transaction.direction == TransactionDirection.INCOMING)
                                EmeraldGreen.copy(alpha = 0.15f)
                            else
                                Color(0xFF1E3A5F)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (transaction.direction == TransactionDirection.INCOMING)
                            Icons.Default.ArrowDownward
                        else
                            Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (transaction.direction == TransactionDirection.INCOMING)
                            EmeraldGreen
                        else
                            Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = transaction.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "${transaction.subtitle} • ${transaction.date}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (transaction.direction == TransactionDirection.INCOMING) "+₱ " else "-₱ ") +
                            String.format(java.util.Locale.US, "%,.2f", transaction.amount),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (transaction.direction == TransactionDirection.INCOMING)
                        EmeraldGreen
                    else
                        Color.White
                )
                Text(
                    text = transaction.status,
                    fontSize = 10.sp,
                    color = EmeraldMint
                )
            }
        }
    }
}
