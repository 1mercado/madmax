package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CompensationMechanics
import com.example.model.UserTier
import com.example.ui.theme.*
import kotlin.math.pow

/**
 * Material 3 Rewards Dashboard Component
 * Calculates and displays the 10-Level Unilevel Commission structure,
 * potential earnings calculator based on user's active tier, and locked vs unlocked potential.
 */
@Composable
fun UnilevelRewardsDashboard(
    userTier: UserTier,
    onUpgradeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Interactive Matrix Simulation State
    var duplicateFactor by remember { mutableStateOf(3) } // e.g. each member refers 3 people
    var packageType by remember { mutableStateOf("₱500 Basic") } // ₱500 Basic vs ₱5,000 Builder
    val packageAmount = if (packageType == "₱500 Basic") 500.0 else 5000.0

    // Calculate projected team size & commission level by level
    val levelCalculations = remember(duplicateFactor, packageAmount, userTier) {
        var runningMembers = 1.0
        CompensationMechanics.LEVEL_PERCENTAGES.map { (lvl, pct) ->
            runningMembers *= duplicateFactor
            // Cap members display for realistic mobile simulation
            val projectedMembers = runningMembers.toLong()
            val commissionPerMember = packageAmount * (pct / 100.0)
            val potentialTotal = projectedMembers * commissionPerMember
            val isUnlocked = CompensationMechanics.isLevelUnlocked(lvl, userTier)
            LevelProjection(
                level = lvl,
                percentage = pct,
                projectedMembers = projectedMembers,
                commissionPerMember = commissionPerMember,
                potentialTotal = potentialTotal,
                isUnlocked = isUnlocked
            )
        }
    }

    val unlockedEarnings = remember(levelCalculations) {
        levelCalculations.filter { it.isUnlocked }.sumOf { it.potentialTotal }
    }

    val lockedEarnings = remember(levelCalculations) {
        levelCalculations.filter { !it.isUnlocked }.sumOf { it.potentialTotal }
    }

    val totalMaxEarnings = unlockedEarnings + lockedEarnings

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. TIER EARNINGS POTENTIAL SUMMARY CARD
        // ==========================================
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = Color(0xF2091D3A)
            ),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0C2448), Color(0xFF07172F))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(CyanNeon.copy(alpha = 0.5f), Color(0x1000E5FF))),
                        RoundedCornerShape(22.dp)
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header: Tier Status & Active Depth
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoGraph,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Unilevel Rewards Potential",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanNeon
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(userTier.badgeColorHex).copy(alpha = 0.2f))
                                .border(1.dp, Color(userTier.badgeColorHex), RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = userTier.title.uppercase(),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(userTier.badgeColorHex)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Active Potential Amount
                    Text(
                        text = "Your Active Potential Earnings",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "₱ " + String.format(java.util.Locale.US, "%,.2f", unlockedEarnings),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        color = EmeraldGreen,
                        letterSpacing = (-0.5).sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // If Basic Tier: Display Missed / Locked Earnings with Upgrade Prompt
                    if (userTier == UserTier.BASIC) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF2A151D))
                                .border(1.dp, ErrorRed.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = Color(0xFFFF8A80),
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Levels 4–10 Locked!",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFF8A80)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Missed Potential: ₱ " + String.format(java.util.Locale.US, "%,.2f", lockedEarnings),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    )
                                }

                                Button(
                                    onClick = onUpgradeClick,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GoldYellow,
                                        contentColor = Color(0xFF241500)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("Upgrade ₱5K", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        // Builder or VIP: All Unlocked Badge
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(EmeraldMint.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "100% Unilevel Depth Unlocked (Levels 1 to 10 Active)",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EmeraldMint
                                )
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. INTERACTIVE SIMULATION MATRIX CONTROLS
        // ==========================================
        OutlinedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.outlinedCardColors(
                containerColor = Color(0xDD0B203E)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.horizontalGradient(listOf(Color(0x3300E5FF), Color(0x1100E5FF)))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Potential Earnings Calculator Matrix",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                // Package Type Switcher (₱500 Basic vs ₱5,000 Builder)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("₱500 Basic", "₱5,000 Builder").forEach { pkg ->
                        val isSelected = packageType == pkg
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) CyanNeon else Color(0xFF0F2C52))
                                .clickable { packageType = pkg }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pkg,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF00222B) else Color.White
                            )
                        }
                    }
                }

                // Duplication Factor Selector
                Text(
                    text = "Assumed Team Duplication (Each Member Invites):",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(2, 3, 4, 5).forEach { factor ->
                        val isSelected = duplicateFactor == factor
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EmeraldMint else Color(0xFF0E2545))
                                .clickable { duplicateFactor = factor }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Power of $factor",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF00222B) else Color.White
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. UNILEVEL COMMISSION STRUCTURE (L1 - L10)
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xCC07162C)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "10-Level Unilevel Commission Breakdown",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (userTier == UserTier.BASIC) "3/10 Active" else "10/10 Active",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (userTier == UserTier.BASIC) GoldYellow else EmeraldGreen
                    )
                }

                // Table of Levels
                levelCalculations.forEach { proj ->
                    LevelProjectionCard(projection = proj, onUpgradeClick = onUpgradeClick)
                }
            }
        }

        // ==========================================
        // 4. VIP 60% INFINITY POOL NOTE
        // ==========================================
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 16.dp,
            backgroundColor = Color(0xFF0C2449),
            borderColor = GoldYellow.copy(alpha = 0.5f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = GoldYellow,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "60% VIP Global Pool Split (To Infinity)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldYellow
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Upon every subscription (₱500) and Builder upgrade (₱5,000) worldwide, 60% is shared equally among VIP 1, 2, and 3 holders across infinite downline levels, while 40% remains in the subscriber's wallet.",
                    fontSize = 11.5.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

data class LevelProjection(
    val level: Int,
    val percentage: Double,
    val projectedMembers: Long,
    val commissionPerMember: Double,
    val potentialTotal: Double,
    val isUnlocked: Boolean
)

@Composable
private fun LevelProjectionCard(
    projection: LevelProjection,
    onUpgradeClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (projection.isUnlocked) Color(0x990D2444) else Color(0x550B1729)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Level badge & commission rate
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            if (projection.isUnlocked) CyanNeon.copy(alpha = 0.2f) else Color(0xFF1B283A)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "L${projection.level}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (projection.isUnlocked) CyanNeon else TextMuted
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Level ${projection.level}  (${projection.percentage}%)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (projection.isUnlocked) Color.White else TextMuted
                        )
                        if (!projection.isUnlocked) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                tint = Color(0xFFFF8A80),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                    Text(
                        text = "₱%.2f / member • %d members".format(
                            projection.commissionPerMember,
                            projection.projectedMembers
                        ),
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            // Projected Earnings
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "₱ " + String.format(java.util.Locale.US, "%,.2f", projection.potentialTotal),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (projection.isUnlocked) EmeraldGreen else Color(0xFFFF8A80)
                )
                Text(
                    text = if (projection.isUnlocked) "Active" else "Builder Req.",
                    fontSize = 9.5.sp,
                    color = if (projection.isUnlocked) EmeraldMint else GoldYellow,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
