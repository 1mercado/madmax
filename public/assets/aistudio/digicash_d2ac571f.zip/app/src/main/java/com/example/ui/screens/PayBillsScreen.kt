package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Biller
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun PayBillsScreen(
    billers: List<Biller>,
    currentBalance: Double,
    onBack: () -> Unit,
    onPayBill: (Biller, String, Double) -> Unit
) {
    val categories = listOf("All", "Electricity", "Water", "Internet", "Cable TV", "Government", "Loans")
    var selectedCategory by remember { mutableStateOf("All") }

    var selectedBillerForPayment by remember { mutableStateOf<Biller?>(null) }
    var accountNumber by remember { mutableStateOf("") }
    var billAmount by remember { mutableStateOf("") }
    var payError by remember { mutableStateOf<String?>(null) }

    val filteredBillers = if (selectedCategory == "All") {
        billers
    } else {
        billers.filter { it.category == selectedCategory }
    }

    DigiCashBackdrop {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Pay Bills",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Category Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) CyanNeon else Color(0xFF0C2442))
                            .border(
                                1.dp,
                                if (isSelected) CyanNeon else CardBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color(0xFF00222B) else Color.White
                        )
                    }
                }
            }

            // Billers List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredBillers) { biller ->
                    BillerCardItem(
                        biller = biller,
                        onClick = {
                            selectedBillerForPayment = biller
                            accountNumber = ""
                            billAmount = ""
                            payError = null
                        }
                    )
                }
            }
        }

        // Bill Payment Modal Dialog
        selectedBillerForPayment?.let { biller ->
            AlertDialog(
                onDismissRequest = { selectedBillerForPayment = null },
                containerColor = Color(0xFF0A1F3B),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyanNeon.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getBillerIcon(biller.category),
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(biller.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(biller.category, fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Available Balance: ₱ %.2f".format(currentBalance),
                            fontSize = 12.sp,
                            color = CyanNeon
                        )

                        OutlinedTextField(
                            value = accountNumber,
                            onValueChange = { accountNumber = it },
                            label = { Text("Account / Reference No.") },
                            placeholder = { Text("e.g. 109283746") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = billAmount,
                            onValueChange = { billAmount = it },
                            label = { Text("Bill Amount") },
                            placeholder = { Text("0.00") },
                            prefix = { Text("₱ ", color = CyanNeon) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        if (biller.fee > 0) {
                            Text(
                                text = "Service fee: ₱ %.2f".format(biller.fee),
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }

                        if (payError != null) {
                            Text(payError ?: "", color = ErrorRed, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amt = billAmount.toDoubleOrNull() ?: 0.0
                            if (accountNumber.isBlank()) {
                                payError = "Please enter an account number."
                                return@Button
                            }
                            if (amt <= 0) {
                                payError = "Please enter a valid amount."
                                return@Button
                            }
                            if (amt + biller.fee > currentBalance) {
                                payError = "Insufficient balance."
                                return@Button
                            }

                            onPayBill(biller, accountNumber, amt)
                            selectedBillerForPayment = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF00222B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Pay Bill", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedBillerForPayment = null }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun BillerCardItem(
    biller: Biller,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        cornerRadius = 16.dp,
        backgroundColor = Color(0xAA0C213E)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(getCategoryColor(biller.category).copy(alpha = 0.15f))
                        .border(1.dp, getCategoryColor(biller.category).copy(alpha = 0.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getBillerIcon(biller.category),
                        contentDescription = biller.category,
                        tint = getCategoryColor(biller.category),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = biller.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = biller.description,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

fun getBillerIcon(category: String): ImageVector {
    return when (category) {
        "Electricity" -> Icons.Default.Bolt
        "Water" -> Icons.Default.WaterDrop
        "Internet" -> Icons.Default.Wifi
        "Cable TV" -> Icons.Default.Tv
        "Government" -> Icons.Default.AccountBalance
        "Loans" -> Icons.Default.CreditCard
        else -> Icons.Default.ReceiptLong
    }
}

fun getCategoryColor(category: String): Color {
    return when (category) {
        "Electricity" -> GoldYellow
        "Water" -> CyanNeon
        "Internet" -> EmeraldMint
        "Cable TV" -> PurpleNeon
        "Government" -> Color(0xFF64B5F6)
        "Loans" -> Color(0xFFFF5252)
        else -> CyanNeon
    }
}
