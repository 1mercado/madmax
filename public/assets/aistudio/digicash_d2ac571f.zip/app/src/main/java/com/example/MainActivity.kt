package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DigiCashRepository
import com.example.data.SimulationResult
import com.example.model.Transaction
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.TransactionReceiptDialog
import com.example.ui.components.SimulationResultDialog
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class AppDestination {
    SPLASH,
    LOGIN,
    MAIN,
    SEND_MONEY,
    RECEIVE_MONEY,
    QR_SCANNER,
    SAVINGS_VAULT,
    PAY_BILLS,
    TOP_UP,
    REWARDS,
    REFERRALS,
    VIP_TIERS,
    BUILDER_UPGRADE,
    TRANSACTIONS_FULL
}

enum class BottomNavTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    TRANSACTIONS("Transactions", Icons.Default.SyncAlt),
    SERVICES("Services", Icons.Default.GridView),
    PROFILE("Profile", Icons.Default.Person)
}

class MainActivity : ComponentActivity() {

    private val repository = DigiCashRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DigiCashTheme {
                val userProfile by repository.userProfile.collectAsStateWithLifecycle()
                val transactions by repository.transactions.collectAsStateWithLifecycle()
                val networkMembers by repository.networkMembers.collectAsStateWithLifecycle()
                val savingsGoals by repository.savingsGoals.collectAsStateWithLifecycle()

                var currentDestination by remember { mutableStateOf(AppDestination.SPLASH) }
                var selectedBottomTab by remember { mutableStateOf(BottomNavTab.HOME) }

                var activeReceiptTransaction by remember { mutableStateOf<Transaction?>(null) }
                var activeSimulationResult by remember { mutableStateOf<SimulationResult?>(null) }

                // Android Back Handling
                BackHandler(enabled = currentDestination != AppDestination.SPLASH) {
                    when (currentDestination) {
                        AppDestination.LOGIN -> currentDestination = AppDestination.SPLASH
                        AppDestination.MAIN -> {
                            if (selectedBottomTab != BottomNavTab.HOME) {
                                selectedBottomTab = BottomNavTab.HOME
                            } else {
                                finish()
                            }
                        }
                        else -> currentDestination = AppDestination.MAIN
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.SPLASH -> {
                            SplashScreen(
                                onGetStarted = { currentDestination = AppDestination.MAIN },
                                onLoginClick = { currentDestination = AppDestination.LOGIN }
                            )
                        }

                        AppDestination.LOGIN -> {
                            LoginScreen(
                                onLoginSuccess = { currentDestination = AppDestination.MAIN },
                                onBackToSplash = { currentDestination = AppDestination.SPLASH }
                            )
                        }

                        AppDestination.MAIN -> {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                containerColor = Color.Transparent,
                                bottomBar = {
                                    NavigationBar(
                                        modifier = Modifier
                                            .windowInsetsPadding(WindowInsets.navigationBars)
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                            .clip(RoundedCornerShape(22.dp))
                                            .border(1.dp, CardBorder, RoundedCornerShape(22.dp)),
                                        containerColor = Color(0xF0081C38),
                                        tonalElevation = 8.dp
                                    ) {
                                        BottomNavTab.values().forEach { tab ->
                                            val isSelected = selectedBottomTab == tab
                                            NavigationBarItem(
                                                selected = isSelected,
                                                onClick = { selectedBottomTab = tab },
                                                icon = {
                                                    Icon(
                                                        imageVector = tab.icon,
                                                        contentDescription = tab.title,
                                                        tint = if (isSelected) CyanNeon else TextSecondary
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        text = tab.title,
                                                        fontSize = 11.sp,
                                                        color = if (isSelected) CyanNeon else TextSecondary
                                                    )
                                                },
                                                colors = NavigationBarItemDefaults.colors(
                                                    indicatorColor = Color(0xFF0C2C55)
                                                )
                                            )
                                        }
                                    }
                                }
                            ) { innerPadding ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(innerPadding)
                                ) {
                                    when (selectedBottomTab) {
                                        BottomNavTab.HOME -> {
                                            HomeScreen(
                                                userProfile = userProfile,
                                                recentTransactions = transactions,
                                                onSendClick = { currentDestination = AppDestination.SEND_MONEY },
                                                onReceiveClick = { currentDestination = AppDestination.RECEIVE_MONEY },
                                                onScanQrClick = { currentDestination = AppDestination.QR_SCANNER },
                                                onPayBillsClick = { currentDestination = AppDestination.PAY_BILLS },
                                                onTopUpClick = { currentDestination = AppDestination.TOP_UP },
                                                onRewardsClick = { currentDestination = AppDestination.REWARDS },
                                                onReferralClick = { currentDestination = AppDestination.REFERRALS },
                                                onBuilderClick = { currentDestination = AppDestination.BUILDER_UPGRADE },
                                                onVipClick = { currentDestination = AppDestination.VIP_TIERS },
                                                savingsGoals = savingsGoals,
                                                onSavingsVaultClick = { currentDestination = AppDestination.SAVINGS_VAULT },
                                                onTransactionClick = { tx -> activeReceiptTransaction = tx },
                                                onViewAllTransactions = {
                                                    selectedBottomTab = BottomNavTab.TRANSACTIONS
                                                },
                                                onProfileClick = {
                                                    selectedBottomTab = BottomNavTab.PROFILE
                                                }
                                            )
                                        }

                                        BottomNavTab.TRANSACTIONS -> {
                                            TransactionsHistoryScreen(
                                                transactions = transactions,
                                                onBack = { selectedBottomTab = BottomNavTab.HOME },
                                                onSelectTransaction = { tx -> activeReceiptTransaction = tx }
                                            )
                                        }

                                        BottomNavTab.SERVICES -> {
                                            ServicesHubScreen(
                                                onSendClick = { currentDestination = AppDestination.SEND_MONEY },
                                                onReceiveClick = { currentDestination = AppDestination.RECEIVE_MONEY },
                                                onScanQrClick = { currentDestination = AppDestination.QR_SCANNER },
                                                onPayBillsClick = { currentDestination = AppDestination.PAY_BILLS },
                                                onTopUpClick = { currentDestination = AppDestination.TOP_UP },
                                                onSavingsVaultClick = { currentDestination = AppDestination.SAVINGS_VAULT },
                                                onRewardsClick = { currentDestination = AppDestination.REWARDS },
                                                onReferralsClick = { currentDestination = AppDestination.REFERRALS },
                                                onBuilderClick = { currentDestination = AppDestination.BUILDER_UPGRADE },
                                                onVipClick = { currentDestination = AppDestination.VIP_TIERS }
                                            )
                                        }

                                        BottomNavTab.PROFILE -> {
                                            ProfileScreen(
                                                userProfile = userProfile,
                                                onNavigateToMembership = { currentDestination = AppDestination.BUILDER_UPGRADE },
                                                onNavigateToTransactions = { selectedBottomTab = BottomNavTab.TRANSACTIONS },
                                                onNavigateToReferrals = { currentDestination = AppDestination.REFERRALS },
                                                onLogout = { currentDestination = AppDestination.SPLASH }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        AppDestination.SEND_MONEY -> {
                            SendMoneyScreen(
                                currentBalance = userProfile.balance,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onSendSuccess = { tx ->
                                    val result = repository.sendMoney(
                                        recipient = tx.recipientOrBiller,
                                        amount = tx.amount,
                                        channel = tx.title.replace("Sent via ", ""),
                                        note = tx.breakdownNote
                                    )
                                    result.onSuccess { newTx ->
                                        activeReceiptTransaction = newTx
                                        currentDestination = AppDestination.MAIN
                                    }
                                }
                            )
                        }

                        AppDestination.RECEIVE_MONEY -> {
                            ReceiveMoneyScreen(
                                userProfile = userProfile,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onSimulateScanReceived = { amount, sender ->
                                    val tx = repository.receiveMoney(sender, amount, "QR Ph instant deposit")
                                    activeReceiptTransaction = tx
                                }
                            )
                        }

                        AppDestination.QR_SCANNER -> {
                            QrScannerScreen(
                                userProfile = userProfile,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onPaymentConfirmed = { recipient, amount, note ->
                                    val result = repository.sendMoney(
                                        recipient = recipient,
                                        amount = amount,
                                        channel = "QR Ph Instant",
                                        note = note
                                    )
                                    result.onSuccess { tx ->
                                        activeReceiptTransaction = tx
                                        currentDestination = AppDestination.MAIN
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onOpenMyQr = {
                                    currentDestination = AppDestination.RECEIVE_MONEY
                                }
                            )
                        }

                        AppDestination.SAVINGS_VAULT -> {
                            SavingsVaultScreen(
                                userProfile = userProfile,
                                goals = savingsGoals,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onCreateGoal = { title, cat, target, initial ->
                                    val res = repository.createSavingsGoal(title, cat, target, initial)
                                    res.onSuccess {
                                        Toast.makeText(this@MainActivity, "Goal '$title' created!", Toast.LENGTH_SHORT).show()
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onDepositToGoal = { goalId, amt ->
                                    val res = repository.depositToGoal(goalId, amt)
                                    res.onSuccess { tx ->
                                        activeReceiptTransaction = tx
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onWithdrawFromGoal = { goalId, amt ->
                                    val res = repository.withdrawFromGoal(goalId, amt)
                                    res.onSuccess { tx ->
                                        activeReceiptTransaction = tx
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        AppDestination.PAY_BILLS -> {
                            PayBillsScreen(
                                billers = repository.billers,
                                currentBalance = userProfile.balance,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onPayBill = { biller, accountNo, amount ->
                                    val result = repository.payBill(biller, accountNo, amount)
                                    result.onSuccess { tx ->
                                        activeReceiptTransaction = tx
                                        currentDestination = AppDestination.MAIN
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        AppDestination.TOP_UP -> {
                            TopUpScreen(
                                currentBalance = userProfile.balance,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onBuyLoad = { phone, telco, amount ->
                                    val res = repository.buyLoad(phone, telco, amount)
                                    res.onSuccess { tx ->
                                        activeReceiptTransaction = tx
                                        currentDestination = AppDestination.MAIN
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onCashIn = { amount, channel ->
                                    val tx = repository.cashIn(amount, channel)
                                    activeReceiptTransaction = tx
                                }
                            )
                        }

                        AppDestination.REWARDS -> {
                            RewardsScreen(
                                userPoints = userProfile.points,
                                userTier = userProfile.tier,
                                rewardsList = repository.rewardsList,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onDailyCheckIn = {
                                    repository.claimDailyPoints()
                                },
                                onRedeemReward = { item ->
                                    val res = repository.redeemReward(item)
                                    res.onSuccess { msg ->
                                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onUpgradeClick = {
                                    currentDestination = AppDestination.BUILDER_UPGRADE
                                }
                            )
                        }

                        AppDestination.REFERRALS -> {
                            ReferralScreen(
                                userProfile = userProfile,
                                networkMembers = networkMembers,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onSimulateSubscription = { level, name ->
                                    val simRes = repository.simulateNewSubscriber(level, name)
                                    activeSimulationResult = simRes
                                },
                                onSimulateBuilderUpgrade = { level, name ->
                                    val simRes = repository.simulateDownlineBuilderUpgrade(level, name)
                                    activeSimulationResult = simRes
                                },
                                onOpenBuilderUpgrade = {
                                    currentDestination = AppDestination.BUILDER_UPGRADE
                                }
                            )
                        }

                        AppDestination.VIP_TIERS -> {
                            VipTiersScreen(
                                userProfile = userProfile,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onUpgradeVip = { targetTier ->
                                    val res = repository.upgradeToVip(targetTier)
                                    res.onSuccess { msg ->
                                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                                        currentDestination = AppDestination.MAIN
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        AppDestination.BUILDER_UPGRADE -> {
                            BuilderUpgradeScreen(
                                userProfile = userProfile,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onConfirmBuilderUpgrade = {
                                    val res = repository.upgradeToBuilder()
                                    res.onSuccess { split ->
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Builder Pack Activated! ₱2,000 (40%) Cashback added to wallet!",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        currentDestination = AppDestination.MAIN
                                    }.onFailure { err ->
                                        Toast.makeText(this@MainActivity, err.message, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        AppDestination.TRANSACTIONS_FULL -> {
                            TransactionsHistoryScreen(
                                transactions = transactions,
                                onBack = { currentDestination = AppDestination.MAIN },
                                onSelectTransaction = { tx -> activeReceiptTransaction = tx }
                            )
                        }
                    }

                    // Transaction Receipt Dialog with Copy to Clipboard Reference ID
                    activeReceiptTransaction?.let { tx ->
                        TransactionReceiptDialog(
                            transaction = tx,
                            onDismiss = { activeReceiptTransaction = null }
                        )
                    }

                    activeSimulationResult?.let { sim ->
                        SimulationResultDialog(
                            result = sim,
                            onDismiss = { activeSimulationResult = null },
                            onOpenBuilderUpgrade = {
                                activeSimulationResult = null
                                currentDestination = AppDestination.BUILDER_UPGRADE
                            }
                        )
                    }
                }
            }
        }
    }
}
