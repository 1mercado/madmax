package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Transaction
import com.example.model.TransactionDirection
import com.example.ui.theme.*

/**
 * TransactionReceipt component that renders an official summary receipt card
 * for fund transfers, bill payments, and top-ups, featuring a copy-to-clipboard
 * transaction reference ID with visual confirmation.
 */
@Composable
fun TransactionReceiptCard(
    transaction: Transaction,
    modifier: Modifier = Modifier,
    onDoneClick: () -> Unit = {},
    onShareClick: (() -> Unit)? = null,
    showDoneButton: Boolean = true
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var isCopied by remember { mutableStateOf(false) }

    LaunchedEffect(isCopied) {
        if (isCopied) {
            kotlinx.coroutines.delay(2200)
            isCopied = false
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF0A203F),
        border = androidx.compose.foundation.BorderStroke(
            1.2.dp,
            Brush.verticalGradient(
                listOf(
                    CyanNeon.copy(alpha = 0.6f),
                    CardBorder.copy(alpha = 0.2f)
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Receipt Header Brand Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(EmeraldMint)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "DIGICASH OFFICIAL RECEIPT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanNeon,
                        letterSpacing = 1.2.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0D2B52))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = transaction.status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Glowing Checkmark Badge
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF88F953), Color(0xFF00F5A0), CyanNeon)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Success",
                    tint = Color(0xFF012920),
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Transaction Successful!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = transaction.title,
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Amount Display
            Text(
                text = "₱ " + String.format(java.util.Locale.US, "%,.2f", transaction.amount),
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (transaction.direction == TransactionDirection.INCOMING) EmeraldGreen else Color.White
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Dotted Separator
            HorizontalDivider(
                color = Color(0x3300E5FF),
                thickness = 1.dp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Transaction Reference ID Card with Copy Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF081A33))
                    .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
                    .clickable {
                        clipboardManager.setText(AnnotatedString(transaction.referenceNumber))
                        isCopied = true
                        Toast.makeText(context, "Reference ID copied to clipboard", Toast.LENGTH_SHORT).show()
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TRANSACTION REFERENCE ID",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextMuted,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = transaction.referenceNumber,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyanNeon
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isCopied) EmeraldMint.copy(alpha = 0.2f) else CyanNeon.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = if (isCopied) Icons.Default.CheckCircle else Icons.Default.ContentCopy,
                            contentDescription = "Copy Reference ID",
                            tint = if (isCopied) EmeraldGreen else CyanNeon,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCopied) "Copied!" else "Copy",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCopied) EmeraldGreen else CyanNeon
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Receipt Breakdown Details
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReceiptDetailRow(
                    label = "Date & Time",
                    value = "${transaction.date} • ${transaction.time}"
                )

                if (transaction.recipientOrBiller.isNotBlank()) {
                    ReceiptDetailRow(
                        label = "Recipient / Biller",
                        value = transaction.recipientOrBiller,
                        isBold = true
                    )
                }

                ReceiptDetailRow(
                    label = "Payment Source",
                    value = "DigiCash Wallet"
                )

                if (transaction.fee > 0) {
                    ReceiptDetailRow(
                        label = "Service Fee",
                        value = "₱ " + String.format(java.util.Locale.US, "%,.2f", transaction.fee)
                    )
                } else {
                    ReceiptDetailRow(
                        label = "Service Fee",
                        value = "FREE",
                        valueColor = EmeraldGreen
                    )
                }

                if (transaction.breakdownNote.isNotBlank()) {
                    ReceiptDetailRow(
                        label = "Note / Breakdown",
                        value = transaction.breakdownNote
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Share Button
                OutlinedButton(
                    onClick = {
                        if (onShareClick != null) {
                            onShareClick()
                        } else {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "DigiCash Receipt\n" +
                                            "Ref ID: ${transaction.referenceNumber}\n" +
                                            "Amount: ₱${String.format(java.util.Locale.US, "%,.2f", transaction.amount)}\n" +
                                            "Title: ${transaction.title}\n" +
                                            "Status: ${transaction.status}\n" +
                                            "Date: ${transaction.date} ${transaction.time}"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Receipt"))
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanNeon),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanNeon)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Share",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Done Button
                if (showDoneButton) {
                    Button(
                        onClick = onDoneClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF88F953), Color(0xFF00F5A0), CyanNeon)
                                    ),
                                    shape = RoundedCornerShape(14.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Done",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF01242E)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionReceiptDialog(
    transaction: Transaction,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            TransactionReceiptCard(
                transaction = transaction,
                onDoneClick = onDismiss,
                showDoneButton = true
            )
        }
    }
}

@Composable
private fun ReceiptDetailRow(
    label: String,
    value: String,
    valueColor: Color = Color.White,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = TextSecondary
        )
        Text(
            text = value,
            fontSize = 13.sp,
            color = valueColor,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}
