package com.example.model

data class ReferralLevelInfo(
    val level: Int,
    val percentage: Double,
    val isUnlocked: Boolean,
    val membersCount: Int,
    val totalEarned: Double
)

object CompensationMechanics {
    const val BASIC_SUBSCRIPTION_AMOUNT = 500.0
    const val BUILDER_UPGRADE_AMOUNT = 5000.0

    // Split percentages
    const val VIP_POOL_PERCENTAGE = 0.60 // 60% split across VIP 1, 2, and 3
    const val SUBSCRIBER_WALLET_PERCENTAGE = 0.40 // 40% remains in subscriber's wallet

    // 10-Level Unilevel Commission percentages
    val LEVEL_PERCENTAGES = listOf(
        1 to 10.0,   // Level 1: 10%
        2 to 5.0,    // Level 2: 5%
        3 to 4.0,    // Level 3: 4%
        4 to 3.0,    // Level 4: 3%
        5 to 2.0,    // Level 5: 2%
        6 to 1.5,    // Level 6: 1.5%
        7 to 1.0,    // Level 7: 1.0%
        8 to 0.75,   // Level 8: 0.75%
        9 to 0.50,   // Level 9: 0.50%
        10 to 0.25   // Level 10: 0.25%
    )

    fun isLevelUnlocked(level: Int, tier: UserTier): Boolean {
        return when (tier) {
            UserTier.BASIC -> level <= 3
            UserTier.BUILDER, UserTier.VIP_1, UserTier.VIP_2, UserTier.VIP_3 -> level <= 10
        }
    }

    /**
     * Calculates the 60/40 breakdown for an event (Subscription or Builder Upgrade)
     */
    fun calculateSplit(amount: Double): SplitBreakdown {
        val vipTotal = amount * VIP_POOL_PERCENTAGE
        val vipShareEach = vipTotal / 3.0 // Split evenly to VIP 1, 2, and 3
        val subscriberCashback = amount * SUBSCRIBER_WALLET_PERCENTAGE
        return SplitBreakdown(
            totalAmount = amount,
            vipPoolTotal = vipTotal,
            vip1Share = vipShareEach,
            vip2Share = vipShareEach,
            vip3Share = vipShareEach,
            subscriberCashback = subscriberCashback
        )
    }

    /**
     * Calculates commission earned at a specific level
     */
    fun calculateCommission(amount: Double, level: Int): Double {
        val pct = LEVEL_PERCENTAGES.firstOrNull { it.first == level }?.second ?: 0.0
        return (amount * (pct / 100.0))
    }
}

data class SplitBreakdown(
    val totalAmount: Double,
    val vipPoolTotal: Double,
    val vip1Share: Double,
    val vip2Share: Double,
    val vip3Share: Double,
    val subscriberCashback: Double
)
