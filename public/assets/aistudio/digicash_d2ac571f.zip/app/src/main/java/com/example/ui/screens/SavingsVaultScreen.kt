package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SavingsGoal
import com.example.model.UserProfile
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun SavingsVaultScreen(
    userProfile: UserProfile,
    goals: List<SavingsGoal>,
    onBack: () -> Unit,
    onCreateGoal: (title: String, category: String, target: Double, initial: Double) -> Unit,
    onDepositToGoal: (goalId: String, amount: Double) -> Unit,
    onWithdrawFromGoal: (goalId: String, amount: Double) -> Unit
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }
    var activeDepositGoal by remember { mutableStateOf<SavingsGoal?>(null) }
    var activeWithdrawGoal by remember { mutableStateOf<SavingsGoal?>(null) }

    val totalSaved = remember(goals) { goals.sumOf { it.currentAmount } }
    val totalTarget = remember(goals) { goals.sumOf { it.targetAmount } }
    val overallProgress = if (totalTarget > 0) (totalSaved / totalTarget).toFloat().coerceIn(0f, 1f) else 0f

    DigiCashBackdrop {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Savings Vault",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(EmeraldMint.copy(alpha = 0.2f))
                        .border(1.dp, EmeraldMint.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "6.0% P.A.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldMint
                    )
                }
            }

            // Total Savings Assets Card
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xF2091F3D)),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFF0F2C54), Color(0xFF081830)))
                        )
                        .border(1.dp, CardBorder, RoundedCornerShape(22.dp))
                        .padding(20.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total Vault Savings",
                                fontSize = 13.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "+₱ 3.70 / day",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "₱ " + String.format(java.util.Locale.US, "%,.2f", totalSaved),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = (-0.5).sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Overall Progress Bar
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Overall Goal Completion",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "${(overallProgress * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanNeon
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { overallProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = CyanNeon,
                                trackColor = Color(0xFF0F2B4D),
                                strokeCap = StrokeCap.Round
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Action Buttons: New Goal & Wallet Info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { showCreateDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyanNeon,
                                    contentColor = Color(0xFF00222B)
                                )
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Goal", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0D2545))
                                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Wallet: ₱" + String.format(java.util.Locale.US, "%,.2f", userProfile.balance),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // Goals List Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Your Specific Savings Goals (${goals.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Tap to manage",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            // Goals LazyColumn
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(goals) { goal ->
                    SavingsGoalCardItem(
                        goal = goal,
                        onDeposit = { activeDepositGoal = goal },
                        onWithdraw = { activeWithdrawGoal = goal }
                    )
                }
            }
        }

        // ==========================================
        // CREATE NEW GOAL DIALOG
        // ==========================================
        if (showCreateDialog) {
            var goalTitle by remember { mutableStateOf("") }
            var targetAmtText by remember { mutableStateOf("10000") }
            var initialDepositText by remember { mutableStateOf("1000") }
            var selectedCategory by remember { mutableStateOf("General") }
            var createError by remember { mutableStateOf<String?>(null) }

            val categories = listOf("Emergency", "Investment", "Travel", "Gadget", "General")

            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                containerColor = Color(0xFF081C38),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Savings, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Create Savings Goal", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = goalTitle,
                            onValueChange = { goalTitle = it },
                            label = { Text("Goal Name") },
                            placeholder = { Text("e.g. New Laptop, Emergency Fund") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = targetAmtText,
                            onValueChange = { targetAmtText = it },
                            label = { Text("Target Amount (₱)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = initialDepositText,
                            onValueChange = { initialDepositText = it },
                            label = { Text("Initial Deposit (₱) (Optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true
                        )

                        // Category Chips
                        Text("Category:", fontSize = 11.sp, color = TextSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            categories.take(3).forEach { cat ->
                                val isSelected = selectedCategory == cat
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) CyanNeon else Color(0xFF0F2E54))
                                        .clickable { selectedCategory = cat }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        cat,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.Black else Color.White
                                    )
                                }
                            }
                        }

                        createError?.let {
                            Text(it, color = ErrorRed, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = targetAmtText.toDoubleOrNull() ?: 0.0
                            val initial = initialDepositText.toDoubleOrNull() ?: 0.0

                            if (goalTitle.isBlank()) {
                                createError = "Please enter a goal name."
                                return@Button
                            }
                            if (target <= 0) {
                                createError = "Enter a valid target amount."
                                return@Button
                            }
                            if (initial > userProfile.balance) {
                                createError = "Initial deposit exceeds wallet balance."
                                return@Button
                            }

                            onCreateGoal(goalTitle, selectedCategory, target, initial)
                            showCreateDialog = false
                            Toast.makeText(context, "Goal '$goalTitle' created!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF00222B)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Create Goal", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // ==========================================
        // DEPOSIT MODAL
        // ==========================================
        activeDepositGoal?.let { goal ->
            var depositAmountText by remember { mutableStateOf("500") }
            var depositError by remember { mutableStateOf<String?>(null) }

            AlertDialog(
                onDismissRequest = { activeDepositGoal = null },
                containerColor = Color(0xFF081C38),
                title = { Text("Deposit to ${goal.title}", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Wallet Balance: ₱ %.2f".format(userProfile.balance), fontSize = 12.sp, color = CyanNeon)
                        OutlinedTextField(
                            value = depositAmountText,
                            onValueChange = { depositAmountText = it },
                            label = { Text("Amount to Deposit") },
                            prefix = { Text("₱ ", color = CyanNeon, fontWeight = FontWeight.Bold) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        depositError?.let { Text(it, color = ErrorRed, fontSize = 11.sp) }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amt = depositAmountText.toDoubleOrNull() ?: 0.0
                            if (amt <= 0) {
                                depositError = "Enter valid amount."
                                return@Button
                            }
                            if (amt > userProfile.balance) {
                                depositError = "Insufficient wallet balance."
                                return@Button
                            }
                            onDepositToGoal(goal.id, amt)
                            activeDepositGoal = null
                            Toast.makeText(context, "Deposited ₱%.2f to ${goal.title}".format(amt), Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF00222B))
                    ) {
                        Text("Deposit", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeDepositGoal = null }) { Text("Cancel", color = TextSecondary) }
                }
            )
        }

        // ==========================================
        // WITHDRAW MODAL
        // ==========================================
        activeWithdrawGoal?.let { goal ->
            var withdrawAmountText by remember { mutableStateOf(goal.currentAmount.toInt().toString()) }
            var withdrawError by remember { mutableStateOf<String?>(null) }

            AlertDialog(
                onDismissRequest = { activeWithdrawGoal = null },
                containerColor = Color(0xFF081C38),
                title = { Text("Withdraw from ${goal.title}", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Available in Goal: ₱ %.2f".format(goal.currentAmount), fontSize = 12.sp, color = EmeraldMint)
                        OutlinedTextField(
                            value = withdrawAmountText,
                            onValueChange = { withdrawAmountText = it },
                            label = { Text("Amount to Withdraw") },
                            prefix = { Text("₱ ", color = CyanNeon, fontWeight = FontWeight.Bold) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        withdrawError?.let { Text(it, color = ErrorRed, fontSize = 11.sp) }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amt = withdrawAmountText.toDoubleOrNull() ?: 0.0
                            if (amt <= 0) {
                                withdrawError = "Enter valid amount."
                                return@Button
                            }
                            if (amt > goal.currentAmount) {
                                withdrawError = "Amount exceeds saved balance."
                                return@Button
                            }
                            onWithdrawFromGoal(goal.id, amt)
                            activeWithdrawGoal = null
                            Toast.makeText(context, "Withdrew ₱%.2f back to Wallet".format(amt), Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldMint, contentColor = Color(0xFF00222B))
                    ) {
                        Text("Withdraw to Wallet", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { activeWithdrawGoal = null }) { Text("Cancel", color = TextSecondary) }
                }
            )
        }
    }
}

@Composable
fun SavingsGoalCardItem(
    goal: SavingsGoal,
    onDeposit: () -> Unit,
    onWithdraw: () -> Unit
) {
    val animatedProgress by animateFloatAsState(
        targetValue = goal.progress,
        animationSpec = tween(durationMillis = 800),
        label = "progress"
    )

    val goalAccent = Color(goal.colorHex)

    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xCC0D2242)),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Title & Category Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(goalAccent.copy(alpha = 0.15f))
                            .border(1.dp, goalAccent.copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getCategoryIcon(goal.category),
                            contentDescription = null,
                            tint = goalAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = goal.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${goal.category} • 6.0% p.a.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Progress Percentage Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (goal.isGoalReached) EmeraldGreen.copy(alpha = 0.2f) else Color(0xFF132F52))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (goal.isGoalReached) "REACHED 🎉" else "${goal.progressPercent}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (goal.isGoalReached) EmeraldGreen else goalAccent
                    )
                }
            }

            // Visual Progress Bar
            Column(modifier = Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(9.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = goalAccent,
                    trackColor = Color(0xFF0F2645),
                    strokeCap = StrokeCap.Round
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "₱ " + String.format(java.util.Locale.US, "%,.2f", goal.currentAmount),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Target: ₱ " + String.format(java.util.Locale.US, "%,.2f", goal.targetAmount),
                        fontSize = 11.5.sp,
                        color = TextSecondary
                    )
                }
            }

            HorizontalDivider(color = Color(0x1500E5FF))

            // Action Buttons (Deposit / Withdraw)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onWithdraw,
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Withdraw", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }

                Button(
                    onClick = onDeposit,
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = goalAccent,
                        contentColor = Color(0xFF00222B)
                    ),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Deposit", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

fun getCategoryIcon(category: String): ImageVector {
    return when (category) {
        "Emergency" -> Icons.Default.HealthAndSafety
        "Investment" -> Icons.Default.TrendingUp
        "Travel" -> Icons.Default.Flight
        "Gadget" -> Icons.Default.Laptop
        else -> Icons.Default.Savings
    }
}
