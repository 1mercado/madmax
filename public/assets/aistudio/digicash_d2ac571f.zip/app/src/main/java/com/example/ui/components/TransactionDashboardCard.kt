package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Transaction
import com.example.model.TransactionDirection
import com.example.model.UserProfile
import com.example.model.UserTier
import com.example.ui.theme.*

/**
 * Modern Material 3 Transaction Dashboard UI Component
 * Displays:
 * 1. Current user balance with privacy toggle and daily flow summary
 * 2. Current tier status badge with unilevel depth indicator and upgrade CTA
 * 3. Recent financial activities list rendered via Material 3 Cards with filtering and receipts
 */
@Composable
fun TransactionDashboard(
    userProfile: UserProfile,
    transactions: List<Transaction>,
    onSendClick: () -> Unit,
    onReceiveClick: () -> Unit,
    onScanQrClick: () -> Unit = onReceiveClick,
    onPayBillsClick: () -> Unit,
    onTopUpClick: () -> Unit,
    onUpgradeTierClick: () -> Unit,
    onTransactionClick: (Transaction) -> Unit,
    onViewAllClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isBalanceHidden by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("All") }

    val filterCategories = listOf("All", "Inflow", "Outflow", "Commissions", "Bills")

    val filteredActivities = remember(selectedFilter, transactions) {
        when (selectedFilter) {
            "Inflow" -> transactions.filter { it.direction == TransactionDirection.INCOMING }
            "Outflow" -> transactions.filter { it.direction == TransactionDirection.OUTGOING }
            "Commissions" -> transactions.filter { it.type == com.example.model.TransactionType.REFERRAL_COMMISSION }
            "Bills" -> transactions.filter { it.type == com.example.model.TransactionType.PAY_BILLS }
            else -> transactions
        }
    }

    // Daily metrics
    val totalInflow = remember(transactions) {
        transactions.filter { it.direction == TransactionDirection.INCOMING }.sumOf { it.amount }
    }
    val totalOutflow = remember(transactions) {
        transactions.filter { it.direction == TransactionDirection.OUTGOING }.sumOf { it.amount }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. PRIMARY BALANCE & TIER STATUS M3 CARD
        // ==========================================
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = Color(0xF20A1D38)
            ),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF0F2B52),
                                Color(0xFF081830)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(CyanNeon.copy(alpha = 0.5f), Color(0x1000E5FF))),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Top Bar: Balance Label + Visibility Eye + Tier Status Pill
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Wallet Balance",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { isBalanceHidden = !isBalanceHidden },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = if (isBalanceHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Balance",
                                    tint = CyanNeon,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Tier Status Badge
                        TierStatusBadge(
                            tier = userProfile.tier,
                            onUpgradeClick = onUpgradeTierClick
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Large Balance Display
                    Text(
                        text = if (isBalanceHidden) "₱ ••••••••" else "₱ " + String.format(java.util.Locale.US, "%,.2f", userProfile.balance),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = (-0.5).sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tier Perks Ribbon
                    TierPerksRibbon(tier = userProfile.tier, onUpgradeClick = onUpgradeTierClick)

                    Spacer(modifier = Modifier.height(16.dp))

                    HorizontalDivider(color = Color(0x2200E5FF))

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Financial Metrics Row (Inflow vs Outflow vs Earnings)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FinancialMetricPill(
                            label = "Today's Inflow",
                            amount = "+₱ " + String.format(java.util.Locale.US, "%,.2f", totalInflow),
                            color = EmeraldGreen,
                            icon = Icons.Default.ArrowDownward
                        )

                        FinancialMetricPill(
                            label = "Today's Outflow",
                            amount = "-₱ " + String.format(java.util.Locale.US, "%,.2f", totalOutflow),
                            color = Color(0xFFFF8A80),
                            icon = Icons.Default.ArrowUpward
                        )

                        FinancialMetricPill(
                            label = "Referral Total",
                            amount = "₱ " + String.format(java.util.Locale.US, "%,.2f", userProfile.totalEarnings),
                            color = GoldYellow,
                            icon = Icons.Default.Stars
                        )
                    }
                }
            }
        }

        // ==========================================
        // 2. QUICK FINANCIAL ACTIONS M3 OUTLINED CARD
        // ==========================================
        OutlinedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.outlinedCardColors(
                containerColor = Color(0xCC091B33)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.horizontalGradient(listOf(Color(0x3300E5FF), Color(0x1100E5FF)))
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                M3ActionIcon(
                    icon = Icons.AutoMirrored.Filled.Send,
                    label = "Send",
                    color = CyanNeon,
                    onClick = onSendClick
                )

                M3ActionIcon(
                    icon = Icons.Default.QrCodeScanner,
                    label = "Scan QR",
                    color = EmeraldMint,
                    onClick = onScanQrClick
                )

                M3ActionIcon(
                    icon = Icons.Default.QrCode,
                    label = "My QR",
                    color = Color(0xFF80D8FF),
                    onClick = onReceiveClick
                )

                M3ActionIcon(
                    icon = Icons.Default.ReceiptLong,
                    label = "Bills",
                    color = PurpleNeon,
                    onClick = onPayBillsClick
                )

                M3ActionIcon(
                    icon = Icons.Default.AddCircle,
                    label = "Top Up",
                    color = Color(0xFF40C4FF),
                    onClick = onTopUpClick
                )
            }
        }

        // ==========================================
        // 2B. SCAN TO PAY WITH QR PH PROMO BANNER
        // ==========================================
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onScanQrClick),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF092547)),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(EmeraldMint, CyanNeon))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Scan QR",
                            tint = Color(0xFF00222B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Scan to Pay with QR Ph",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(EmeraldMint.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "0% FEE",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldMint
                                )
                            }
                        }
                        Text(
                            text = "Tap to open camera and scan any bank or merchant QR",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = CyanNeon,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // ==========================================
        // 3. RECENT FINANCIAL ACTIVITIES M3 SECTION
        // ==========================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xCC07162C)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section Title + View Full History
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Recent Financial Activities",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${filteredActivities.size} transactions recorded",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    TextButton(
                        onClick = onViewAllClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "View All",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Filter Chips Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filterCategories.forEach { category ->
                        val isSelected = selectedFilter == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = category },
                            label = {
                                Text(
                                    text = category,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanNeon,
                                selectedLabelColor = Color(0xFF00222B),
                                containerColor = Color(0xFF0C2442),
                                labelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) CyanNeon else CardBorder
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                // Activities List using M3 ElevatedCard items
                if (filteredActivities.isEmpty()) {
                    EmptyActivityCard(filter = selectedFilter)
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        filteredActivities.take(5).forEach { transaction ->
                            ActivityM3Card(
                                transaction = transaction,
                                onClick = { onTransactionClick(transaction) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Material 3 Status Badge for the user's active tier
 */
@Composable
private fun TierStatusBadge(
    tier: UserTier,
    onUpgradeClick: () -> Unit
) {
    val tierColor = Color(tier.badgeColorHex)

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(tierColor.copy(alpha = 0.15f))
            .border(1.dp, tierColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable(onClick = onUpgradeClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(tierColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = tier.title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = tierColor,
            letterSpacing = 0.5.sp
        )
        if (tier == UserTier.BASIC) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "UPGRADE",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = GoldYellow,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF332000))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
    }
}

/**
 * Information banner showing active unilevel depth
 */
@Composable
private fun TierPerksRibbon(
    tier: UserTier,
    onUpgradeClick: () -> Unit
) {
    val depthDescription = when (tier) {
        UserTier.BASIC -> "Levels 1–3 Active (10%, 5%, 4%) • Upgrade to Builder for L4–L10"
        UserTier.BUILDER -> "All 10 Unilevel Levels Active (10% down to 0.25%)"
        UserTier.VIP_1 -> "VIP 1 Infinity Pool Active (20% Pool Share + L1-10)"
        UserTier.VIP_2 -> "VIP 2 Infinity Pool Active (20% Pool Share + VIP Perks)"
        UserTier.VIP_3 -> "VIP 3 Executive Infinity Pool Active (Top Tier Worldwide)"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF071C38))
            .clickable(onClick = onUpgradeClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = Color(tier.badgeColorHex),
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = depthDescription,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                maxLines = 1
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(12.dp)
        )
    }
}

/**
 * Metric chip showing inflow, outflow, or referral total
 */
@Composable
private fun FinancialMetricPill(
    label: String,
    amount: String,
    color: Color,
    icon: ImageVector
) {
    Column {
        Text(
            text = label,
            fontSize = 10.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = amount,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

/**
 * Material 3 Action Icon button
 */
@Composable
private fun M3ActionIcon(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp, horizontal = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f))
                .border(1.dp, color.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White
        )
    }
}

/**
 * Individual Activity Item rendered with an M3 ElevatedCard
 */
@Composable
private fun ActivityM3Card(
    transaction: Transaction,
    onClick: () -> Unit
) {
    val isIncoming = transaction.direction == TransactionDirection.INCOMING
    val accentColor = if (isIncoming) EmeraldGreen else Color.White
    val typeIcon = when (transaction.type) {
        com.example.model.TransactionType.SEND_MONEY -> Icons.AutoMirrored.Filled.Send
        com.example.model.TransactionType.RECEIVE_MONEY -> Icons.Default.CallReceived
        com.example.model.TransactionType.PAY_BILLS -> Icons.Default.ReceiptLong
        com.example.model.TransactionType.TOP_UP_LOAD -> Icons.Default.PhoneAndroid
        com.example.model.TransactionType.REFERRAL_COMMISSION -> Icons.Default.AutoGraph
        com.example.model.TransactionType.BUILDER_UPGRADE -> Icons.Default.RocketLaunch
        com.example.model.TransactionType.SUBSCRIPTION_REBATE -> Icons.Default.CurrencyExchange
        com.example.model.TransactionType.REWARDS_REDEEM -> Icons.Default.CardGiftcard
        else -> Icons.Default.SwapHoriz
    }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = Color(0xAA0C213E)
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Circle Badge
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isIncoming) EmeraldGreen.copy(alpha = 0.15f) else Color(0xFF132F52)
                        )
                        .border(
                            1.dp,
                            if (isIncoming) EmeraldGreen.copy(alpha = 0.35f) else Color(0x3300E5FF),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = typeIcon,
                        contentDescription = null,
                        tint = if (isIncoming) EmeraldGreen else CyanNeon,
                        modifier = Modifier.size(19.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = transaction.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "${transaction.subtitle} • ${transaction.date} ${transaction.time}",
                        fontSize = 10.5.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (isIncoming) "+₱ " else "-₱ ") +
                            String.format(java.util.Locale.US, "%,.2f", transaction.amount),
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
                Text(
                    text = transaction.status,
                    fontSize = 10.sp,
                    color = EmeraldMint,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun EmptyActivityCard(filter: String) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = Color(0x550C213E)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Receipt,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No activities under \"$filter\"",
                fontSize = 12.sp,
                color = TextSecondary
            )
        }
    }
}
