package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.*

@Composable
fun DigiCashBackdrop(
    modifier: Modifier = Modifier,
    showEarthBackdrop: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalThemeIsDark.current

    // The gradient backdrop remains consistent across both dark and light modes,
    // preserving the signature cosmic fintech gradient and glowing Earth
    val gradientColors = if (isDark) {
        listOf(
            Color(0xFF01142F), // Deep space sapphire
            Color(0xFF021F45), // Radiant navy
            Color(0xFF042958), // Electric space blue
            Color(0xFF011736)  // Base deep sapphire
        )
    } else {
        listOf(
            Color(0xFF062A5A), // Luminous rich sapphire
            Color(0xFF0D3C7C), // Radiant azure glow
            Color(0xFF1451A0), // Electric ocean blue
            Color(0xFF082D60)  // Base luminous sapphire
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = gradientColors))
    ) {
        // Glowing Earth backdrop (full screen coverage; no black scrim; luminous and vibrant)
        if (showEarthBackdrop) {
            Image(
                painter = painterResource(id = R.drawable.img_earth_backdrop),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Ambient glow canvas for radiant cyan & sapphire lighting
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cyanOrbAlpha = if (isDark) 0x35 else 0x48
            val tealOrbAlpha = if (isDark) 0x28 else 0x38
            val atmosphericAlpha = if (isDark) 0x30 else 0x44

            // Top right cyan ambient orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x00E5FF).copy(alpha = cyanOrbAlpha / 255f), Color(0x0000E5FF)),
                    center = Offset(size.width * 0.85f, size.height * 0.12f),
                    radius = size.width * 0.65f
                ),
                radius = size.width * 0.65f,
                center = Offset(size.width * 0.85f, size.height * 0.12f)
            )

            // Middle left teal glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x00F5A0).copy(alpha = tealOrbAlpha / 255f), Color(0x0000F5A0)),
                    center = Offset(size.width * 0.1f, size.height * 0.45f),
                    radius = size.width * 0.55f
                ),
                radius = size.width * 0.55f,
                center = Offset(size.width * 0.1f, size.height * 0.45f)
            )

            // Bottom cyan atmospheric radiance
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x00E5FF).copy(alpha = atmosphericAlpha / 255f), Color(0x0000E5FF)),
                    center = Offset(size.width * 0.5f, size.height * 0.75f),
                    radius = size.width * 0.85f
                ),
                radius = size.width * 0.85f,
                center = Offset(size.width * 0.5f, size.height * 0.75f)
            )
        }

        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    borderColor: Color? = null,
    backgroundColor: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val isDark = LocalThemeIsDark.current
    val effectiveBg = backgroundColor ?: if (isDark) BgCardGlass else Color(0x38FFFFFF)
    val effectiveBorder = borderColor ?: if (isDark) CardBorder else Color(0x6000E5FF)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(effectiveBg)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        effectiveBorder,
                        effectiveBorder.copy(alpha = 0.12f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
    ) {
        content()
    }
}
