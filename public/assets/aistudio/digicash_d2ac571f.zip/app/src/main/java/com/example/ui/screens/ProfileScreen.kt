package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.components.DigiCashBackdrop
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    userProfile: UserProfile,
    onNavigateToMembership: () -> Unit,
    onNavigateToTransactions: () -> Unit,
    onNavigateToReferrals: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showAccountDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    DigiCashBackdrop {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Screen Title
            Text(
                text = "My Profile",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            // User Info Hero Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 22.dp,
                backgroundColor = Color(0xDD0C2242)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(userProfile.tier.badgeColorHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile.name.split(" ").map { it.take(1) }.joinToString(""),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = userProfile.name,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = userProfile.email,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(userProfile.tier.badgeColorHex).copy(alpha = 0.2f))
                                .border(1.dp, Color(userProfile.tier.badgeColorHex), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = userProfile.tier.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(userProfile.tier.badgeColorHex)
                            )
                        }
                    }
                }
            }

            // Options List Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 20.dp,
                backgroundColor = Color(0xCC0A1F3B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    ProfileMenuRow(
                        icon = Icons.Default.Person,
                        title = "Account Information",
                        onClick = { showAccountDialog = true }
                    )
                    HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))

                    ProfileMenuRow(
                        icon = Icons.Default.Security,
                        title = "Security & Privacy",
                        onClick = { showSecurityDialog = true }
                    )
                    HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))

                    ProfileMenuRow(
                        icon = Icons.Default.WorkspacePremium,
                        title = "Membership & Upgrade",
                        subtitle = "${userProfile.tier.title} • Tap to view perks",
                        onClick = onNavigateToMembership
                    )
                    HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))

                    ProfileMenuRow(
                        icon = Icons.Default.ReceiptLong,
                        title = "Transaction History",
                        onClick = onNavigateToTransactions
                    )
                    HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))

                    ProfileMenuRow(
                        icon = Icons.Default.Group,
                        title = "Referral Program",
                        subtitle = "10 Levels • ₱500 Subscription • ₱5,000 Builder",
                        onClick = onNavigateToReferrals
                    )
                    HorizontalDivider(color = Color(0x1500E5FF), modifier = Modifier.padding(horizontal = 16.dp))

                    ProfileMenuRow(
                        icon = Icons.Default.HelpOutline,
                        title = "Help & Support",
                        onClick = { showHelpDialog = true }
                    )
                }
            }

            // Logout Button
            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.6f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed)
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Out", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(70.dp))
        }

        // Account Info Dialog
        if (showAccountDialog) {
            AlertDialog(
                onDismissRequest = { showAccountDialog = false },
                containerColor = Color(0xFF091F3C),
                title = { Text("Account Information", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Name: ${userProfile.name}", color = TextSecondary)
                        Text("DigiCash ID: ${userProfile.id}", color = CyanNeon, fontWeight = FontWeight.Bold)
                        Text("Phone: ${userProfile.phone}", color = TextSecondary)
                        Text("Email: ${userProfile.email}", color = TextSecondary)
                        Text("Current Tier: ${userProfile.tier.title}", color = EmeraldMint, fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAccountDialog = false }) {
                        Text("Done", color = CyanNeon)
                    }
                }
            )
        }

        // Security Dialog
        if (showSecurityDialog) {
            AlertDialog(
                onDismissRequest = { showSecurityDialog = false },
                containerColor = Color(0xFF091F3C),
                title = { Text("Security & Privacy", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("• Biometrics Authentication: ACTIVE", color = EmeraldGreen)
                        Text("• 6-digit DigiCash MPIN: PROTECTED", color = EmeraldGreen)
                        Text("• Zero-Trust Encryption: ENABLED", color = CyanNeon)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSecurityDialog = false }) {
                        Text("Close", color = CyanNeon)
                    }
                }
            )
        }

        // Help & Support Dialog
        if (showHelpDialog) {
            AlertDialog(
                onDismissRequest = { showHelpDialog = false },
                containerColor = Color(0xFF091F3C),
                title = { Text("DigiCash 24/7 Support", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Need assistance with subscriptions, rewards, or transfers?", color = TextSecondary, fontSize = 12.sp)
                        Text("Email: support@digicash.ph", color = CyanNeon, fontWeight = FontWeight.Bold)
                        Text("Hotline: (02) 8888-DIGI", color = Color.White)
                        Text("Live Agent: Available 24/7 in-app", color = EmeraldMint)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showHelpDialog = false
                            Toast.makeText(context, "Support agent connected", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color.Black)
                    ) {
                        Text("Start Live Chat")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showHelpDialog = false }) {
                        Text("Close", color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun ProfileMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = CyanNeon,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = TextMuted,
            modifier = Modifier.size(16.dp)
        )
    }
}
