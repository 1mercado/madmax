package com.example.model

data class Biller(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val fee: Double = 0.0,
    val code: String
)

data class RewardItem(
    val id: String,
    val title: String,
    val description: String,
    val pointsCost: Int,
    val category: String,
    val rewardValueFormatted: String,
    val cashCreditAmount: Double = 0.0
)

data class TelcoOption(
    val name: String,
    val prefixList: List<String>,
    val colorHex: Long
)

data class NetworkMember(
    val id: String,
    val name: String,
    val phone: String,
    val level: Int,
    val tier: UserTier,
    val joinedDate: String,
    val earningsGenerated: Double
)
